# Rewriting the startup-benchmark Python skills in Kotlin — options research

*Research conducted 2026-09-01 by a dedicated agent with web access. Sections 1–4 and 6 are complete;
section 5 (testing/parity) is partial — its thread had not reported when this was written and is
marked accordingly. Repo facts were read from the checkout; everything else carries a URL and the
source's date. Items the researcher could not verify are collected in §9 rather than smoothed over.*

---

## 0. What is being replaced (repo facts)

- **Build stack already present**: Gradle wrapper **9.7.1**, Kotlin Gradle plugin **2.4.10**, AGP **9.3.2**, kotlinx-serialization **1.8.1** and coroutines **1.10.2** in `gradle/libs.versions.toml`; Moshi 1.15.2 used only by the Gradle plugin. `gradle.properties` enables the configuration cache with `problems=fail`, parallel builds, build cache, and a 4 GB Kotlin daemon. CI runs on **JDK 21**. Existing pure-JVM modules (`embrace-gradle-plugin`, `embrace-jvm-conventions`) target JVM 11 with `allWarningsAsErrors`.
- **The Python being replaced**: stdlib-only (`json, statistics, random, subprocess, csv, argparse, hashlib, urllib.request, zipfile, http.server`). Shared `stats.py` hand-rolls a type-7 quantile, ICC/design effect, two-stage cluster bootstrap (`random.Random(seed).choice`), cluster permutation test (`rng.shuffle`), Cliff's delta, TOST, Benjamini–Hochberg, power/MDE. Scripts call `adb -s <serial> …`, `<example-app>/gradlew -p <app> …` (a *different* Gradle project from this repo), and `trace_processor -q file.sql trace` whose CSV they parse.
- **Design consequence**: the Kotlin tool will itself spawn `gradlew` and hold a terminal for minutes-long campaigns, so **how the tool is launched matters more than raw JVM start-up** (§3.3).

---

## 1. Kotlin scripting options

### 1.1 `.main.kts` (kotlin-main-kts)
- Run with `kotlin foo.main.kts`, `kotlinc -script`, or a `#!/usr/bin/env kotlin` shebang. Dependencies via `@file:Repository`/`@file:DependsOn("g:a:v")`; other scripts via `@file:Import`. Compiled scripts cached under `$TMPDIR/main.kts.compiled.cache`, keyed on source. — [MainKts.md](https://github.com/Kotlin/kotlin-script-examples/blob/master/jvm/main-kts/MainKts.md) (undated).
- **JetBrains position**: "We will continue to develop the `.main.kts` script type"; deprecated: CLI/IDE REPL, JSR-223, KotlinScriptMojo, `kotlin-scripting-ide-services`. — [State of Kotlin Scripting 2024](https://blog.jetbrains.com/kotlin/2024/11/state-of-kotlin-scripting-2024/) (2024-11-22; quotes re-confirmed). No 2025–26 follow-up found.
- **Open bugs**: `@file:Import` uses a **stale cache** — edits to an imported file are not detected unless the main script changes ([KT-42101](https://youtrack.jetbrains.com/issue/KT-42101), 2020, open as of 2026-01). `@file:DependsOn` via the `kotlin` runner fails without a manual `-classpath` to `kotlin-main-kts.jar` ([KT-82109](https://youtrack.jetbrains.com/issue/KT-82109), 2025-11, open). K2 script support: no official completion statement found — flagged.
- **Sibling module reuse**: none first-class — `publishToMavenLocal` + `@file:DependsOn`, or `-classpath <jar>`.
- **Cold start**: no main-kts-specific number; generic `kotlinc` hello-world 3–5 s ([KT-52460](https://youtrack.jetbrains.com/issue/KT-52460), 2022). No evidence any runner reuses the Kotlin compile daemon.
- **Debugging**: IntelliJ "Kotlin Script" run config; top-level breakpoints can be missed — wrap in an `object` ([JetBrains help](https://www.jetbrains.com/help/idea/run-debug-configuration-kotlin-script.html); [Worldline](https://blog.worldline.tech/2025/08/19/kotlin-scripting.html), 2025-08-19).
- **Install**: `brew install kotlin` (2.4.10, depends on Homebrew `openjdk` 26) — [formulae.brew.sh](https://formulae.brew.sh/formula/kotlin) (live 2026-09-01). The repo's Gradle-embedded compiler is not usable from the shell.
- **Precedent**: AndroidX keeps `.main.kts` utilities in [`development/`](https://github.com/androidx/androidx/tree/androidx-main/development).

### 1.2 kscript
v4.2.3 is the **last release, 2023-07-22**; 43 open issues — [kscripting/kscript](https://github.com/kscripting/kscript). Tap-only Homebrew. Delegates to whatever `kotlinc` is on PATH; Kotlin 2.4 compatibility unverified. **Maintenance risk: high.**

### 1.3 JBang (Kotlin)
Kotlin labelled **[EXPERIMENTAL]** in JBang's docs ([Multiple languages](https://www.jbang.dev/documentation/jbang/latest/multiple-languages.html)). `//DEPS` Maven only; local jars only via `--class-path` ([discussion #1723](https://github.com/orgs/jbangdev/discussions/1723)). "Slower first time (compiler download)"; no numbers. `brew install jbang` (core, 0.141.0). No documented Kotlin debugging story.

### 1.4 Kotlin Notebook / kotlin-jupyter
Not a fit regardless: cell-based, IDE-resident, no run-with-args-exit-with-status mode. Additionally **sunset**: unbundled from IntelliJ 2026.2, no JetBrains build for 2026.3+ — [kotlin-notebook-sunset](https://blog.jetbrains.com/idea/2026/06/kotlin-notebook-sunset/) (June 2026; re-confirmed).

### 1.5 Amper → "Kotlin Toolchain"
Renamed **Kotlin Toolchain 0.11.0, Alpha** ([blog](https://blog.jetbrains.com/amper/2026/06/kotlin-toolchain-0-11/), June 2026). Requires `module.yaml`/`project.yaml`; **no single-file mode**. Alpha, mid-rename — not a foundation for a tools module inside an existing Gradle repo.

### 1.6 Plain `kotlinc -script`
No dependency resolution, no cache, same compiler cold start. Not useful here.

---

## 2. Compiled-CLI options

### 2.1 Gradle JVM module + `application` plugin
- `installDist` → `build/install/<name>/bin/<name>` POSIX launcher with the full runtime classpath; `run --args`; `--debug-jvm`; `applicationDefaultJvmArgs`; launcher honours `<APPNAME>_OPTS` and needs `JAVA_HOME` or `java` on PATH — [Gradle Application Plugin](https://docs.gradle.org/current/userguide/application_plugin.html) (9.7.1). Extra entry points via additional `JavaExec` tasks.
- Fat jar: Shadow is now **`com.gradleup.shadow`** 9.5.x, Gradle ≥ 9.2, Java 17 — [gradleup.com/shadow](https://gradleup.com/shadow/). **Not needed** if using `installDist` for an in-repo tool.
- Config cache: `JavaExec` ✓ supported; imperative `Project.exec()` removed in Gradle 9 ([status matrix](https://docs.gradle.org/current/userguide/configuration_cache_status.html)).
- **Edit→run latency**: no citable number for a warm no-op `installDist` in a ~50-module repo. Mechanism references: [Introducing Configuration Caching](https://blog.gradle.org/introducing-configuration-caching) (2020); [K2 performance](https://blog.jetbrains.com/kotlin/2024/04/k2-compiler-performance-benchmarks-and-how-to-measure-them-on-your-projects/) (2024). **Estimate, flagged**: warm daemon + config-cache hit ≈ 1–3 s no-op, 3–6 s one-file change; measure with [gradle-profiler](https://github.com/gradle/gradle-profiler).
- **JVM cold start**: HelloWorld ≈ **62 ms** on an M4 MacBook Pro — [inside.java: A Deep Dive into JVM Start-up](https://inside.java/2025/01/28/jvm-start-up/) (2025-01-28). A small Kotlin CLI with kotlinx-serialization + Clikt: estimate 150–400 ms (unsourced). AppCDS: one-flag `-XX:+AutoCreateSharedArchive -XX:SharedArchiveFile=…` from **JDK 19** ([Sip of Java #067](https://inside.java/2022/09/26/sip067/)); 20–50% start-up reduction, anecdotal ([Red Hat](https://developers.redhat.com/articles/2024/01/23/speed-java-application-startup-time-appcds), 2024). JDK 24/25 AOT cache ([JEP 483](https://openjdk.org/jeps/483), [JEP 514](https://openjdk.org/jeps/514), [JEP 515](https://openjdk.org/jeps/515)). For a tool dominated by `adb`/`gradlew`/`trace_processor` this is a nicety.
- Precedent: Square's [gradle-dependencies-sorter](https://github.com/square/gradle-dependencies-sorter) keeps a separate `app` CLI module built via `installShadowDist`.

### 2.2 Kotlin/Native macOS binary
Libraries: kotlinx-serialization ✓, coroutines ✓, Clikt ✓ (per-arch CI status conflicting in secondary sources), Okio ✓; `macosArm64` Tier 1. **Subprocess is the pain point**: no stdlib API; cinterop `posix_spawn`/`popen`, or [kommand](https://github.com/kgit2/kommand) (Rust-backed) / [ksubprocess](https://github.com/Xfel/ksubprocess). No Apache stats/CSV. Release linking "an order of magnitude" slower, non-incremental ([docs](https://kotlinlang.org/docs/native-improving-compilation-time.html)). `kotlin.random.Random(seed)` is XorWow, reproducible only within a stdlib version.

### 2.3 GraalVM native-image
Plugin `org.graalvm.buildtools.native`; kotlinx-serialization reflection-free ✓; Jackson/Moshi need metadata; **kotlinx-coroutines has recurring native-image bugs** ([oracle/graal#783](https://github.com/oracle/graal/issues/783), [#9046](https://github.com/oracle/graal/issues/9046)). Build 2–5 min small ([secondary](https://www.javacodegeeks.com/2025/10/native-image-for-java-microservices-faster-startup-times-and-smaller-memory-footprint.html), 2025-10). **GraalVM CE dropped macOS x64 at 25.0.2** — arm64 only ([release notes](https://www.graalvm.org/release-notes/JDK_25/), 2026-01-20).

---

## 3. Structuring Kotlin so it feels like scripting

### 3.1 Layout
**One Gradle JVM module, one dispatcher `main`, one file per "script" as a Clikt subcommand, shared core in the same module** (a second `:core` module only if unit-test isolation demands). Alternatives — many `JavaExec` tasks (each run pays Gradle entry), one subproject per tool (config-phase cost). No named OSS repo found implementing exactly "dispatcher + Clikt subcommands" (flagged); the pattern is Clikt's documented idiom.

### 3.2 CLI parsing
- **Clikt 5.1.0**, actively maintained, Mordant-backed help ([ajalt/clikt](https://github.com/ajalt/clikt); release date reported inconsistently — verify).
  ```kotlin
  class StartupTools : CliktCommand() { override fun run() = Unit }
  class AnalyzeStartup : CliktCommand() { val traces by argument().path(); override fun run() { … } }
  fun main(args: Array<String>) = StartupTools().subcommands(AnalyzeStartup(), TrendReport(), FleetCampaign()).main(args)
  ```
- **kotlinx-cli is dead**: "This library is obsolete. It is effectively unmaintained." ([Kotlin/kotlinx-cli](https://github.com/Kotlin/kotlinx-cli)).
- picocli 4.7.7 (2025-04) — Java, annotation-based, best GraalVM story; only if native-image is chosen.

### 3.3 Fast edit→run loop and the `./run` wrapper
- Build once, run directly: `./gradlew -q :startup-tools:installDist && startup-tools/build/install/startup-tools/bin/startup-tools <sub> args`.
- **Do not launch the tool through `./gradlew run` for this workload**: `run` gives the child an empty stdin ([gradle/gradle#8255](https://github.com/gradle/gradle/issues/8255)), turns a non-zero exit into a `GradleException` ([JavaExec DSL](https://docs.gradle.org/current/dsl/org.gradle.api.tasks.JavaExec.html)), breaks terminal detection so colours vanish ([ajalt/clikt#428](https://github.com/ajalt/clikt/issues/428)), and `--args` quoting is fragile. It would also nest a Gradle daemon around the tool's own `gradlew -p <example-app>` for the whole campaign.
- A checked-in wrapper (`tools/startup`) doing the two steps above with `exec … "$@"` is the natural idiom (~10 lines of bash; `./gradlew -q --console=plain :startup-tools:installDist`, then `exec` the launcher). Add a `--no-build`/env toggle for data-only iteration. No named OSS repo found using exactly this (flagged); closest precedents are `gradlew` itself and Square's `installShadowDist` flow.

---

## 4. Libraries for the specific needs

| Need | Recommendation | Notes |
|---|---|---|
| Process execution | **Plain `ProcessBuilder`** — `redirectErrorStream(true)` or drain both streams on threads, `waitFor(timeout)` + `destroyForcibly()`, `directory()`, `environment()`, `onExit()` | Deadlock when not draining both streams is documented ([Javadoc](https://docs.oracle.com/en/java/javase/24/docs/api/java.base/java/lang/ProcessBuilder.html)). Wrappers exist ([pgreze/kotlin-process](https://github.com/pgreze/kotlin-process) 1.5.1, 2025-01; [lordcodes/turtle](https://github.com/lordcodes/turtle) 0.10.0, 2024-05) — solo-maintainer, no JetBrains-blessed option. |
| JSON/JSONL | **kotlinx-serialization-json** (in catalog at 1.8.1; latest 1.11.0, 2026-04) — `decodeFromStream`/`encodeToStream`, `JsonElement` for dynamic trees; JSONL = `lineSequence()` + per-line decode | NaN/Infinity rejected unless `allowSpecialFloatingPointValues` — Python's `json` emits bare `NaN`, so the stores may contain it. **No key-sort option** ([#121](https://github.com/Kotlin/kotlinx.serialization/issues/121)) — build a sorted `JsonObject` to match `sort_keys=True`. Jackson silently writes NaN as `"NaN"`. |
| CSV (trace_processor output) | **Apache Commons CSV 1.14.1** (2025-07) or hand-rolled | Perfetto prints each statement's result as CSV with strings quoted; exact NULL formatting to be checked against the pinned binary. |
| Table printing | Hand-rolled `padEnd` aligner or **Mordant 3.x** if colour wanted | Picnic (2023) and asciitable (2017) — avoid. |
| Statistics | **Hand-roll** median/type-7 quantile/bootstrap/permutation (as `stats.py` does); optionally **Apache Commons Statistics `descriptive` 1.2** (2025-09) for `Quantile.withEstimationMethod(HF7)` | **Default is HF8, not HF7** — set explicitly to match `stats.quantile`. Commons Math 4 still beta; Hipparchus 4.0.2 is the maintained fork. kotlin-statistics archived 2022. |
| Seeded PRNG, CPython parity | **`org.apache.commons.math3.random.MersenneTwister(int[])`** — 3.6.1 source verified: `setSeed(int[])` is a faithful `init_by_array`; `next(bits)` returns the top bits ([source](https://raw.githubusercontent.com/apache/commons-math/MATH_3_6_1/src/main/java/org/apache/commons/math3/random/MersenneTwister.java)). **No JVM library reproduces CPython's `random` layer**; ~80 lines hand-written on top, verified from CPython source: seed = `abs(int)` → 32-bit LE words → `init_by_array` ([`_randommodule.c`](https://github.com/python/cpython/blob/main/Modules/_randommodule.c)); `random()` = `((a>>>5)*67108864.0 + (b>>>6)) / 9007199254740992.0`; `getrandbits(k≤32)` = top k bits; `_randbelow(n)` = rejection on `getrandbits(n.bit_length())`; `shuffle` = Fisher–Yates from the end with `j = _randbelow(i+1)`; `choice(seq)` = `seq[_randbelow(len)]` ([`Lib/random.py`](https://github.com/python/cpython/blob/main/Lib/random.py)). `stats.py` uses only `Random(12345)`, `.choice`, `.shuffle` — parity is tractable. |

---

## 5. Testing and parity — PARTIAL

- **Framework**: repo default is JUnit 4.13.2 via `embrace-jvm-conventions`; a tools module may use JUnit 5 with `@TestFactory` for one `DynamicTest` per fixture file ([JUnit 5 dynamic tests](https://junit.org/junit5/docs/current/user-guide/#writing-tests-dynamic-tests)). Declare the fixture dir as a task input.
- **Golden-file comparison**: parse expected and actual into `JsonElement` and compare trees — `JsonObject` equality is `Map` equality, key-order-insensitive. Compare numbers as doubles with relative tolerance (1e-9), never as strings.
- **Float-format pitfalls (recall — verify)**: `Double.toString` became shortest-round-trip in JDK 19 (JDK-4511638) but exponent thresholds differ from Python `repr`; Java `Formatter` `%.2f` rounds HALF_UP on the exact expansion while Python is correctly rounded half-even (visible at exact ties like 0.125); `Math.round`/`roundToInt` are half-up, Python `round()` half-even — use `Math.rint`.
- **Numeric pitfalls specific to `stats.py`**: `quantile()` is `lo*(1-frac)+hi*frac` — bit-exact if operation order is preserved; `statistics.mean` is exactly rounded (Fraction-based) whereas Kotlin `average()` is naive summation → last-ulp differences in ICC/DEFF, so use tolerances there; Python 3.12+ `sum()` uses compensated summation (recall). Bootstrap/permutation outputs *can* be bit-exact once the RNG layer matches.
- **Parity harness design**: (a) `dump_golden.py` runs each `stats.py` function on checked-in inputs with `seed=12345`, writes `json.dumps(sort_keys=True)` fixtures; (b) Kotlin tests replay and compare; (c) optional differential test invoking `python3` via `ProcessBuilder`, skipped with `assumeTrue(pythonAvailable)`; (d) CLI-level: run old and new on the same JSONL store and diff JSON reports until the Python is deleted. Keep the Python unchanged until the golden suite passes; delete in one commit.

---

## 6. macOS-specific distribution

- **JDK**: Gradle 9.x runs on JVM 17–26 ([compatibility](https://docs.gradle.org/current/userguide/compatibility.html)); AGP 9.0 needs JDK 17+ ([AGP 9.0 notes](https://developer.android.com/build/releases/agp-9-0-0-release-notes)). Any developer who can build this repo has JDK ≥ 17; CI has 21. `gradlew` downloads Gradle only, not a JDK; `org.gradle.toolchains.foojay-resolver-convention` can auto-provision one ([plugin portal](https://plugins.gradle.org/plugin/org.gradle.toolchains.foojay-resolver-convention)).
- **Homebrew (live 2026-09-01)**: `kotlin` 2.4.10, `openjdk` 26, `openjdk@21`, `temurin` cask, `jbang` 0.141.0 (core); `kscript` tap-only. Homebrew `openjdk` needs a `sudo ln -sfn … /Library/Java/JavaVirtualMachines/openjdk.jdk` for `/usr/bin/java` discovery.
- **Apple silicon**: Kotlin/Native `macosArm64` Tier 1; GraalVM CE arm64-only on macOS since 25.0.2; `adb` universal since platform-tools 32.0.0 (2022); locally built binaries carry no `com.apple.quarantine`, so no Gatekeeper prompt.

---

## 7. Comparison table

| Approach | Cold start | Edit→run | Dependency mgmt | Shared code | Debuggability | Testability | macOS install | Maturity / risk |
|---|---|---|---|---|---|---|---|---|
| **Gradle JVM module + `installDist` + wrapper** | ≈60 ms JVM + class loading; est. 150–400 ms; AppCDS −20–50% | est. 1–3 s no-op, 3–6 s one-file change (measure) | version catalog, Maven Central | native (same module) | full IntelliJ, `--debug-jvm`, JFR | JUnit + golden fixtures in CI | none beyond building the repo | very low; first-party |
| Fat jar (Shadow) | same | same + merge | same | same | same | same | same | low; adds nothing over installDist |
| `.main.kts` | 3–5 s+ first run; cached re-run still JVM + runtime | recompile per edit; stale-import bug | `@file:DependsOn`; sibling via mavenLocal | `@file:Import` of `.kts` only | script config; breakpoint quirk | none | `brew install kotlin` | low-medium; committed but open runner bugs |
| kscript | like main.kts | like main.kts | `//DEPS` | `@file:Import` | generic | none | tap + kotlinc | **high**: last release 2023 |
| JBang (Kotlin) | "slower first time" | recompile | `//DEPS` Maven only | prebuilt jar only | undocumented | none | `brew install jbang` | medium: EXPERIMENTAL |
| Kotlin Notebook | n/a | n/a | `%use` | n/a | cell debugger | none | plugin | **sunset June 2026** |
| Amper / Kotlin Toolchain | n/a | Alpha | `module.yaml` | standalone only | IDE | yes, Alpha | new wrapper | Alpha, mid-rename |
| Kotlin/Native | ms | release link 10× slower | KMP-only libs | yes | LLDB, weak | kotlin.test | via KGP | medium-high: subprocess, no stats libs |
| GraalVM native-image | ms | minutes | metadata needed; coroutines bugs | yes | weak | test on JVM | GraalVM, **arm64-only** | medium |

---

## 8. Recommendation

**Recommended: a single Gradle JVM module (e.g. `:startup-tools`, `kotlin("jvm")` + `application`), one Clikt dispatcher `main`, one Kotlin file per former Python script as a subcommand, shared `stats`/`tooling`/`tracehealth` packages in the same module, `installDist`, and a checked-in `tools/startup` bash wrapper that runs `./gradlew -q --console=plain :startup-tools:installDist` and then `exec`s the generated launcher with `"$@"`.**

1. **The repo already pays for everything this needs** — Gradle 9.7.1, KGP 2.4.10, kotlinx-serialization, daemon, build cache, configuration cache, all warmed by normal development. Every scripting option adds a Homebrew install and a second compiler outside Gradle.
2. **"Edit a script-sized file to change behaviour" is preserved** — one file per subcommand; the wrapper rebuilds on every run.
3. **Heavy subprocess use and multi-minute campaigns favour a plain JVM process launched outside Gradle** — stdin, exit codes and colours intact; no outer Gradle daemon wrapping the tool's own `gradlew` and `adb` children.
4. **Bit-exact RNG parity is a JVM-library problem** — Commons Math 3's `MersenneTwister` is a verified `init_by_array`; the CPython layer is ~80 lines. Kotlin/Native has no equivalent; `.main.kts` could use it but cannot unit-test it.
5. **Testability** — golden-fixture JUnit tests in the same module run in CI; impossible with scripts.
6. Cold start (≈0.2–0.4 s) is irrelevant next to the seconds-to-minutes each command spends in `adb`, `gradlew` and `trace_processor`.

Repo-specific notes: keep the module **off** `embrace-jvm-conventions` (JVM 11 / `languageVersion 2.0` / `allWarningsAsErrors` are for shipped SDK code; target the JDK developers actually run, 17+); be configuration-cache clean because `problems=fail` is set; keep detekt passing.

**Runner-up: `.main.kts`** — one script per former Python script, shared code via `@file:Import`. Prefer it **only if all hold**: no Gradle wiring wanted; scripts rarely edited (3–5 s recompiles and KT-42101 tolerable); no unit tests or CI wanted; every user willing to `brew install kotlin`. AndroidX uses it for exactly this kind of utility, so it is not a dead end — but it trades away testability and the warm build loop the repo already has.

kscript, JBang-Kotlin, Notebook and Amper/Kotlin Toolchain are not recommended (stale, experimental, sunset, Alpha). Kotlin/Native and GraalVM are not recommended: millisecond start-up buys nothing here while subprocess ergonomics, build minutes and (for Graal) coroutine/arch constraints cost real time.

---

## 9. Flagged as unverified or not found

- Any published cold-start number specific to `.main.kts`, JBang-Kotlin, or a small Kotlin/Native or GraalVM CLI; JVM cold-start for *this* CLI.
- Warm-daemon no-op `installDist` / one-file-change timings in a ~50-module repo (estimates only).
- Official confirmation that `.main.kts` is fully K2-supported; whether any scripting runner reuses the compile daemon.
- Whether the Kotlin Toolchain 0.11 post itself deprecates Gradle-based Amper.
- Clikt 5.1.0 exact release date; Mordant 3.1.0 date; picocli versions after 4.7.7; KGP 2.4.x row on the compatibility page.
- Closure of oracle/graal#9046; AppCDS wiring via `$APP_HOME` in start scripts (needs a spike).
- trace_processor CSV NULL/number formatting for the pinned binary.
- Section 5 "recall" items: JDK-4511638, exponent thresholds, `Formatter` rounding, Python 3.12 `sum()`, `JsonObject` equality; current versions of JsonUnit/JSONassert/Kotest-JSON.
- No named OSS repo implementing the exact "dispatcher + Clikt subcommands" module or the `./run`→installDist wrapper idiom.
