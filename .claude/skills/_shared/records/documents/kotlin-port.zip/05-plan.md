# Porting the startup-analysis skills to Kotlin — the plan

*2026-09-01. Synthesis of `01-python-inventory.md` (what exists), `02-methodology-to-replicate.md`
(what must be preserved), `03-toolchain-facts.md` (what the repo and tools provide) and
`04-kotlin-research.md` (how Kotlin can be made to feel like scripting). Effort figures are rough
working estimates for one engineer, labelled as such; they are there to size phases against each
other, not to be held to.*

## 0. The decision in one paragraph

Build **one Gradle JVM module in this repo** — working name `:startup-tools` — with a **Clikt
dispatcher** and **one Kotlin file per former Python script** as a subcommand, sharing a single core
library for statistics, JSON schemas, Perfetto access and device access. Ship it through Gradle's
`application` plugin (`installDist`) and a **checked-in `tools/startup` wrapper** that rebuilds
incrementally and then `exec`s the launcher, so the developer loop is `edit file → tools/startup
<command> …`, the same shape as Python with a few seconds of incremental compile in between. **Nothing
new to install**: anyone who can build the SDK (JDK ≥ 17, which Gradle 9 already requires) can run
every analysis. Validate the port against the Python with **golden fixtures generated from the real
stores**, a **CPython-compatible RNG** so bootstrap and permutation results are bit-exact rather than
"close", and a **captured trace fixture set** for the Perfetto layer — then delete the Python in one
commit once the parity suite is green. Along the way, fix the defects the inventory found rather than
reproducing them, and record every place the port deliberately departs from the Python.

## 1. Why this shape and not another

The research compared eight approaches. Three facts decide it for *this* codebase:

1. **The Python is stdlib-only and the Gradle build already contains everything the Kotlin needs** —
   Gradle 9.7.1, Kotlin 2.4.10, kotlinx-serialization, the daemon, build and configuration caches.
   Every scripting option (`.main.kts`, kscript, JBang) adds a Homebrew install and a second compiler
   outside Gradle; the compiled-module option adds nothing.
2. **The tools spend their time in child processes** — `adb`, `gradlew -p examples/ExampleApp`,
   `trace_processor` — for seconds to hours. JVM cold start (≈0.2–0.4 s) is noise against that, which
   removes the only argument for Kotlin/Native or GraalVM, both of which cost real time in subprocess
   ergonomics, build minutes, and (GraalVM) arm64-only macOS support. It also means the tool must be
   launched *outside* Gradle: `./gradlew run` swallows stdin, converts exit codes to exceptions, breaks
   terminal detection, and would nest a Gradle daemon around the campaign's own `gradlew` children.
3. **The statistics need reproducibility a script cannot test.** The method of record is a seeded
   two-stage cluster bootstrap and permutation test. Bit-exact parity with the Python is achievable on
   the JVM (Commons Math 3's `MersenneTwister` is a verified `init_by_array`; CPython's `random` layer
   is ~80 lines on top) and *provable* only with a test suite that runs in CI — which a compiled module
   has and a script does not.

**Runner-up, and when to prefer it:** `.main.kts` scripts with `@file:Import` shared code, kept beside
the SKILL.md files. JetBrains is committed to the format and AndroidX uses it for exactly this kind of
utility. Choose it only if the team wants *no* Gradle wiring, rarely edits the scripts (3–5 s recompile
per edit, plus a stale-import cache bug), and accepts no unit tests. That is not this team's stated
goal ("as easy to modify and run as Python", with correctness the project has repeatedly had to earn
back), so it is the fallback, not the plan.

## 2. Target architecture

### 2.1 Module

```
startup-tools/                      ← new Gradle subproject, JVM only
  build.gradle.kts                  kotlin("jvm"), application, kotlin-serialization, detekt
  src/main/kotlin/io/embrace/startup/
    Main.kt                         Clikt dispatcher: one `subcommands(...)` list
    cli/                            ONE FILE PER FORMER SCRIPT — the "script-sized" edit surface
      Analyze.kt  Variance.kt  HypothesisTests.kt  OutlierFactors.kt  FactorsReport.kt
      CrossDeviceSections.kt  Probe.kt  FleetCampaign.kt  VerifyArms.kt
      ReferenceSet.kt  Ingest.kt  Trend.kt  Submit.kt  Reproducibility.kt
      MatrixPlan.kt  CellRunner.kt  CompatPatch.kt  MatrixReport.kt  TraceHealth.kt  ServeTrace.kt
    core/                           the consolidated library (replaces every duplicated helper)
      stats/     Quantile.kt Cluster.kt (bootstrap, permutation, ICC/DEFF) EffectSize.kt Power.kt Compare.kt
      rng/       CPythonRandom.kt   (MT19937 + CPython's random(), getrandbits, _randbelow, shuffle, choice)
      json/      StoreRecord.kt ReferenceSet.kt CorpusRecord.kt SectionMedians.kt LegRecord.kt  (@Serializable)
      text/      Table.kt (padEnd aligner)  Csv.kt (trace_processor output)
      repo/      RepoRoot.kt (one implementation)  Worktree.kt  BorrowedState.kt
    perfetto/                       trace_processor access
      Prebuilt.kt                   fetch native prebuilt by URL + sha256, pin v57.2, cache dir logic
      TraceProcessor.kt             query(trace, sql) via -q; WarmSession via `server unix` + `query --remote`
      TraceHealth.kt                loss counters × canary → five verdicts
      sql/  startup_metrics.sql  variance_metrics.sql  outlier_metrics.sql  init_window_sched.sql  foreign_gc_overlap.sql  (resources, unchanged)
    device/                         adb
      Adb.kt                        ONE wrapper (serial, timeout, capture)  Probe.kt  Thermal.kt (ONE parser)  CoolGate.kt  CrashBuffer.kt
    campaign/                       the leg/pass machinery shared by fleet campaigns and matrix cells
      LegRunner.kt  Resume.kt  InstallRetry.kt  PropagationGate.kt  Sweep.kt
  src/test/kotlin/...               golden + parity tests
  src/test/resources/fixtures/      copied stores, section JSONs, leg arrays; small trace set (§3.2)
tools/startup                       bash wrapper: build if needed, exec launcher, "$@"
```

Build facts that constrain this (from `03-toolchain-facts.md`): do **not** apply
`embrace-jvm-conventions` (JVM 11 / `languageVersion 2.0` / `allWarningsAsErrors` are for shipped
SDK code); apply detekt directly with the repo's `config/detekt/detekt.yml` and a module baseline;
target JVM 17 (CI has 21; Gradle 9 requires ≥ 17); keep the build configuration-cache clean because
`org.gradle.configuration-cache.problems=fail` is set repo-wide.

### 2.2 The wrapper

```bash
#!/usr/bin/env bash
# tools/startup — build the tools incrementally (warm daemon: seconds), then run them directly.
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
if [[ -z "${STARTUP_TOOLS_NO_BUILD:-}" ]]; then
  "$REPO/gradlew" -q --console=plain :startup-tools:installDist
fi
exec "$REPO/startup-tools/build/install/startup-tools/bin/startup-tools" "$@"
```

`STARTUP_TOOLS_NO_BUILD=1` skips Gradle when iterating on data only. The tool runs as a plain JVM
process with real stdin, real exit codes, and no Gradle daemon wrapped around the campaign.

### 2.3 Fidelity policy — what is ported as-is, consolidated, or fixed

The inventory shows the Python is not one program but several written over two weeks. A literal port
would reproduce three quantile definitions, five `repo_root`s, five adb wrappers, three thermal
parsers, four canonical-section lists, and two broken CLI contracts. The policy, decided up front so
every departure is deliberate and recorded:

| class | rule | examples |
|---|---|---|
| **Preserve exactly** — a published number or a stored record depends on it | byte-for-byte behaviour, tested by golden fixture | store record schema; `derive()` fields; ingest guards (truncation `<0.9×`, over-long `>1.1×`, lossy `>2%`, empty); trend `verdict()` and the fixed baseline; `group_key` including `sdk_version`; corpus redaction allowlist and `unit_token`; SQL files verbatim |
| **Consolidate** — pure duplication with one intended meaning | one implementation in `core/`, tested once | `pearson`, adb wrapper (one timeout policy, explicit per call), `repo_root`, thermal parsing, trace_processor CSV extraction, published-version test, section lists (one source of truth with per-view subsets) |
| **Fix** — the Python is wrong and nothing depends on the wrongness | fix, and note it in the port log | `cell_runner`→`fleet_campaign` CLI mismatch (cells will call the shared `LegRunner`, not a subprocess); SKILL.md invocations (`--reference-set`, `--cells`); `HUNT_FIELDS` naming fields never written; fixed-name temp SQL files (use `createTempFile`); `artifact_sync`'s absolute manifest path; `ram_class` vocabulary split |
| **Decide** — the Python is inconsistent and *something* published depends on each side | one canonical choice, legacy path kept only where a stored number needs it, both labelled | **Quantile**: canonical = Type-7 (HF7) interpolation as in `stats.py`; the store's `derived.p90/p95` keep the index-based definition under an explicit `legacy_index` label so existing records stay reproducible; the version-evolution tables are re-derived once under both and the deltas recorded. **Run shape**: 10×20 is the standard; the two SKILL.md files saying 4×50 are corrected. **Instrument name**: composed window is the metric of record; `emb-sdk-start` is 9.2.0+; `app-embrace-start` is dropped as a default. |
| **Wire in** — correct code nobody calls | make it the only implementation | `stats.compare()` becomes what every report uses; `BorrowedState` wraps the version pin in `CompatPatch` and `CellRunner` |
| **Drop** | not ported | nothing — every script has a live use. `serve_trace` becomes ~30 lines on `com.sun.net.httpserver` (zero deps) |

### 2.4 Two deliberate improvements the port enables

- **Pin the Perfetto engine, not the launcher.** The current "v46.0" is a Python launcher that
  fetches **Perfetto v57.2** native prebuilts, so the recipe's recorded version does not identify the
  engine and the toolchain secretly requires python3. `Prebuilt.kt` fetches the native
  `trace_processor_shell` by URL and sha256 (mac-arm64 `98a41b80…`, mac-amd64 `c0f61397…`) and records
  **v57.2**. This is a recipe change and is recorded as one; parity on fixtures should be exact because
  the launcher was already running v57.2.
- **Parse each trace once.** Ingest runs three separate `trace_processor` processes per trace (window,
  signals, health) — three full parses. The native binary offers `server unix` warm sessions with
  `query --remote`; `WarmSession` loads a trace once and runs every query against it. On a 200-trace
  leg that is ~200 parses instead of ~600. The `-q` path stays as the simple, always-works fallback
  and as the parity oracle.

## 3. How the port is validated

Parity is proven in layers, each with its own oracle, so a failure localises.

### 3.1 Layer A — pure functions against Python-generated goldens (no devices, no Perfetto)

A small Python script, `dump_golden.py`, run **once** against the *existing* Python with `seed=12345`,
writes `json.dumps(sort_keys=True)` fixtures for: every public function in `stats.py` over synthetic
and real inputs (the 12-record store gives 200-window arms); `derive()` over every store record;
`trend_report` verdicts over the store; `reproducibility_report` over a synthetic corpus;
`matrix_plan` over `plan-example.json`; `factors_report`/`hypothesis_tests`/`cross_device_sections`
over synthetic `passN.json` inputs. Kotlin JUnit tests replay the same inputs and compare **JSON trees**
(key-order-insensitive) with doubles compared at relative tolerance 1e-9 — never as strings, because
Java and Python format doubles differently at exponent thresholds and round ties differently.

**What must be bit-exact:** bootstrap CI bounds and permutation p-values, once `CPythonRandom`
reproduces `Random(12345).choice/.shuffle`. That is the strongest available proof that the method of
record was carried over intact. **What is tolerance-based by nature:** means and variances (Python's
`statistics.mean` is exactly rounded; Kotlin's `average()` is naive summation — last-ulp drift in
ICC/DEFF is expected and harmless).

The fixtures are frozen JSON committed with the module. After cutover, Python is not needed to run
them.

### 3.2 Layer B — the Perfetto layer against a captured trace set

**No raw trace survives anywhere today** (the scratchpad purge took the last ones), so this layer has
no fixture until one is captured. Step 0 includes **one short device run** — one pass of 20 on two
devices (a fast and a slow one) — with traces copied to a durable location. Of those, a **minimal set
(3–5 traces, gzipped, a few MB)** is committed under `src/test/resources/traces/` so CI can exercise
SQL execution, CSV parsing, `[NULL]` handling and trace-health verdicts; the rest stays local and the
corresponding tests skip with `assumeTrue` when absent. Oracle: the Python `analyze_startup`,
`variance_analysis`, `outlier_factors`, `trace_health` and `ingest_run` outputs on the same files,
generated once and frozen.

### 3.3 Layer C — end-to-end differential, until cutover

While both toolchains exist, a `parity/` script runs the old and new CLIs on the same inputs — the
real stores, the section JSONs, the leg arrays, the trace fixtures — and diffs their JSON/`--json`
outputs. The Python is **kept unchanged** until every differential is clean, then deleted in a single
commit that also switches the SKILL.md files to `tools/startup <command>`.

### 3.4 Layer D — device and campaign behaviour (needs hardware)

- `probe`: run old and new on the same connected device, diff the topology JSON.
- `fleet-campaign`: a **dry-run mode** that resolves paths, reads thermal state, and prints the
  `gradlew` command without running it; then **one real pass** on one device, checked against the
  crash buffer and health gate; then a **kill test** — SIGTERM mid-pass, confirm process-group death,
  device sweep, borrowed-state restore, and clean resume.
- `verify-arms` and the **propagation gate**: exercised on the existing pair of APK builds when a
  worktree is next created; the gate's thresholds (movers ≤ −25%, control within ±15%) are validated
  against X33's recorded section deltas.

## 4. Incremental steps

Each phase ends in a working, reviewable state with its own gate. Phases 3–4 (file-only analyses) and
phase 5 (device layer) are independent and can proceed in parallel or in either order.

| # | phase | delivers | gate to pass | rough effort |
|---|---|---|---|---|
| **0** | **Foundations** | `:startup-tools` module wired into `settings.gradle.kts`; `tools/startup` wrapper; Clikt dispatcher with `--version` and `--help`; detekt passing; CI job; fixtures copied from `claude-output/` into test resources; **trace fixture capture** (one short device run, needs a device — the only hardware dependency in the first four phases); `dump_golden.py` written and its outputs frozen | `tools/startup --help` runs from a clean clone in one command; CI green; goldens committed | 2–3 days |
| **1** | **Core library** | `Quantile` (HF7 + `legacy_index`), `Cluster` (ICC/DEFF, bootstrap, permutation), `EffectSize`, `Power`, `Compare`; `CPythonRandom`; `@Serializable` schemas for store/reference-set/corpus/sections/legs; `Table`, `Csv`, `RepoRoot` | **Layer A green**, with bootstrap/permutation **bit-exact** against the seed-12345 goldens | 3–4 days (RNG parity is the fiddly part) |
| **2** | **Perfetto layer** | `Prebuilt` (native v57.2 by URL+sha256, cache dirs as in `tooling.py`), `TraceProcessor.query` via `-q`, CSV parse with header sentinel and `[NULL]`, `TraceHealth`; SQL files as resources | **Layer B green**: identical `(what,k,val)` rows and identical health verdicts on the trace fixtures | 2 days |
| **3** | **File-only analyses** | `analyze`, `variance`, `hypothesis-tests`, `outlier-factors`, `factors-report`, `cross-device-sections`, `trend`, `reproducibility`, `matrix-plan`, `matrix-report`, `trace-health`, `serve-trace` — each one file in `cli/` calling `core/` | **Layer C differential clean** for every command over fixtures; each report also renders side-by-side with the Python's text for a human read | 4–5 days |
| **4** | **Store writers** | `reference-set`, `ingest`, `submit` — all guards, drift check, provenance, redaction, `--dry-run`/`--force` | ingest of the trace fixture produces a record equal to the Python's modulo timestamps; guard behaviour identical on synthetic truncated / over-long / lossy inputs; `artifact_sync` ported with a repo-relative manifest | 2–3 days |
| **5** | **Device & campaign layer** | `Adb`, `Thermal`, `CoolGate`, `CrashBuffer`, `probe`; `LegRunner` + `Resume` + `InstallRetry` + `Sweep`; `fleet-campaign`; `verify-arms`; `cell-runner` calling `LegRunner` directly (fixing the CLI mismatch); `compat-patch` wrapped in `BorrowedState`; `PropagationGate` | **Layer D**: probe parity on real devices; one real pass; kill/restore/resume test passes; gate validated against X33's deltas | 5–6 days incl. device time |
| **6** | **Warm sessions** | `WarmSession` (server unix + `query --remote`) behind the same interface; ingest/analyze use it when available and fall back to `-q` | results identical to the `-q` path on fixtures; wall time per 200-trace leg measured and recorded | 1–2 days |
| **7** | **Cutover** | SKILL.md files rewritten to `tools/startup …`; references updated (run shape 10×20 everywhere, instrument names, corrected invocations); Python deleted in one commit; port log (every "Fix"/"Decide" departure) written into the multi-device skill's references; recipe change (`trace_processor_version: v57.2`) recorded in the store's `store.md` | a clean clone runs every documented workflow with the Kotlin tool only; `python3` not invoked anywhere | 1–2 days |

**Total, rough:** 20–27 working days **for a human engineer writing the code**; phases 3–4 and 5 in
parallel would bring the calendar down to ~3 weeks. The single hard external dependency is **device
time in phase 0** (trace fixtures) and **phase 5** (campaign validation).

**If Claude writes the code and Hanson reviews**, authoring compresses roughly four- to fivefold and
the total is **~5–8 days of session time**, with the calendar set by review turnaround and device
access rather than by typing:

| phase | human | Claude writes, human reviews | what bounds it |
|---|---|---|---|
| 0 | 2–3 d | ~1 d | one device run; the five decisions |
| 1 | 3–4 d | ~1 d | RNG bit-exactness is a test-fix loop of a few hours |
| 2 | 2 d | hours | needs phase 0's traces |
| 3 | 4–5 d | ~1 d | differential fixing across 12 commands |
| 4 | 2–3 d | ½–1 d | — |
| 5 | 5–6 d | 1–1½ d | device passes and the kill/restore test run at device speed |
| 6 | 1–2 d | hours | — |
| 7 | 1–2 d | hours + review | — |

### Delivery mode — how review is scheduled sets the calendar

Session time is ~5–8 days in every Claude-writes mode; what moves is the waiting between phases and
where the irreversible risk lands.

| mode | session time | calendar | where the risk sits |
|---|---|---|---|
| human writes | 20–27 d | ~3 weeks parallelised | spread through the writing |
| Claude writes, **synchronous review at every gate** (8 gates) | 5–8 d | ~8–12 d if reviews are same-day; **~3 weeks if each takes a day** — latency dominates and it converges on the human number | low: nothing compounds past a gate |
| Claude writes, **self-validates and moves on; review async and at the end** | 5–7 d | **~1–1.5 weeks** continuous, plus a final review pass and one fix-up round | an undetected error compounds across phases until review |

**Why async is viable here:** the gates are mechanical, not judgment calls — bit-identical bootstrap
CIs, an empty differential, matching trace rows. They do not need a human to pass. **Where it is
not, and the rules that follow** (this session's void campaign is the case study — a check on the wrong
thing, then a judgment call past an inconclusive result):

1. **A gate passes on zero diff or a pre-declared tolerance, never on "close enough."** Any unexplained
   difference blocks the phase and is listed for the reviewer, not resolved unilaterally.
2. **Two synchronous checkpoints remain:** the five decisions before phase 0, and **a review before
   phase 7**, because deleting the Python is the one step that is expensive to walk back. Everything
   before it is additive and mechanically gated.
3. **A phase log is written as work proceeds**, so the async review reads what was decided and why,
   not just a diff.

**Recommended: the hybrid** — async through phases 0–6 under those rules, sync only at the decisions
and before cutover. Roughly a week and a half of calendar, with review time spent where it has the most
leverage. Sync-at-every-gate buys little safety the mechanical gates do not already provide, and costs
most of the speed.

### Parallelism with subagents — a further 30–40%, not a multiple

**What parallelises well:** phase 3's twelve file-only commands (one file each, own golden, own
differential — the layout is the partition; 3–4 agents × 3–4 commands); phase 2 alongside phase 1's
statistics (it depends only on the CSV helper and repo utilities); phase 4 alongside 3; phase 5's *code*
alongside 3 and 4; and in phase 0, the goldens script, the module skeleton and the fixture copy.

**What does not:** the core contract (schemas + `core/` API surface) must exist before fan-out and
should be written serially by one author so twelve files share one convention; the CPython RNG parity
is a single test-fix loop; **integration and every gate judgment stay with one reviewer** — agents may
run the parity suites, no agent decides a diff is acceptable; and device time is serial on hardware
(one campaign at a time, quiet host) regardless of who wrote the code.

| step | who | session time |
|---|---|---|
| 0 skeleton ∥ goldens ∥ fixture capture | 3 agents; device run bounds it | ½–1 d |
| 1a core contract | **serial, one author** | ¼ d |
| 1b stats + RNG ∥ 2 Perfetto ∥ 3 fan-out ∥ 4 writers ∥ 5 code | agents; RNG loop is the long pole | ½–1 d |
| integrate, run every parity suite, triage diffs | one reviewer | ½–1 d |
| 5 validation on devices; 6 warm sessions | device speed | ½–1 d |
| 7 cutover after the sync review | — | ¼ d + review |
| **total** | | **~3½–5 d** (from 5–7); calendar ~4–6 working days in the hybrid mode |

Conditions: **strict file ownership** (no two agents touch one file) and a **conventions note** written
with the core contract (error handling, exit codes, how a command reports a parity failure), with
detekt enforcing the mechanical half. Part of the saving is spent on coordination — precise per-agent
specs and curating their output. **Net:** async review is the larger lever (three weeks → a week and a
half); subagents take a further day or two off, chiefly in phase 3.

What does not compress in any mode: device time, Gradle build-test cycles, and **review** — which is
both the critical path and the quality gate. This session's own record is the argument for not
rushing it: a 2.5-hour campaign ran against the wrong SDK because a flag was checked and a version pin
was not, and a claim about 9.1.0 was published before it was verified. Fast generation does not
produce that kind of correctness; review does.

## 5. Risks, and what is done about each

| risk | mitigation |
|---|---|
| **CPython RNG parity is fiddly** — seed expansion, `_randbelow` rejection sampling, `shuffle` direction all have to match exactly | It is ~80 lines with a verified engine underneath, and it is *checkable*: the first golden compares `Random(12345)`'s raw `random()` sequence. If parity proves impossible, fall back to tolerance-based CI comparison (10k resamples make bounds stable to ~1%) and record that the method, not the numbers, was preserved |
| **No trace fixtures exist** | Phase 0 captures them deliberately, in a durable location, and commits a minimal gzipped set; tests skip cleanly when the larger local set is absent |
| **Pinning v57.2 changes the recipe** | Parity on fixtures proves the numbers do not move (the launcher already ran v57.2); the change is recorded in `store.md` and the recipe field, not slipped in |
| **Quantile canonicalisation changes published numbers** | `legacy_index` preserved for stored `derived` fields; tables re-derived once under both definitions with deltas published before anything is relabelled |
| **Configuration cache `problems=fail`** | No `Project.exec` at configuration time; the module has only standard tasks; verified in phase 0 |
| **Detekt strictness on a tools module** | Apply the repo config with a module baseline; keep trailing-comma and naming rules from the start rather than baselining them away |
| **Scope creep into "while we're here" redesign** | The fidelity policy (§2.3) is the boundary: consolidate and fix are allowed; new behaviour waits for phase 6+ and is listed |
| **The Python keeps changing during the port** | Freeze it: the goldens are generated once from a tagged commit; any Python change after that must be mirrored, or the port re-baselined explicitly |

## 6. Decisions needed before phase 0 starts

1. **Module name and location** — `:startup-tools` at the repo root (matches `embrace-*` siblings) vs a `tools/` directory. Recommendation: root-level `startup-tools/`, wrapper at `tools/startup`.
2. **Trace fixtures in the repo** — commit 3–5 gzipped traces (a few MB) so CI covers the Perfetto layer, or keep all traces out and accept that layer is local-only. Recommendation: commit the minimal set.
3. **Quantile canonicalisation** — adopt HF7 as canonical with `legacy_index` retained for stored fields (recommended), or keep index-based everywhere and document it.
4. **JVM target** — 17 (recommended; matches what developers run and unlocks AppCDS if ever wanted) vs the conventions' 11.
5. **Where the port log lives** — a `references/port-log.md` in the multi-device skill (recommended) or a section in each SKILL.md.

## 7. What "done" looks like

A developer clones the repo on a Mac with a JDK, plugs in a device, and runs
`tools/startup probe <serial> mid-a out/` → `tools/startup fleet-campaign …` →
`tools/startup ingest …` → `tools/startup trend --store …`, and every number matches what the Python
produced on the same inputs — proven by a CI suite, not by inspection. There is no `python3` anywhere
in the workflow, the Perfetto engine version in every record is the one that actually ran, each trace
is parsed once, the cluster statistics have one implementation that every report uses, and the two
CLI contracts and four documentation errors the inventory found no longer exist.
