# What the Python encodes — the methodology a port must preserve

*Written 2026-08-26 as the conceptual companion to `01-python-inventory.md`. The inventory says what
the files are; this says what they are FOR, and which behaviours are load-bearing. Everything here was
earned by a specific incident in the 2026-08 campaigns; where a rule has a scar, the scar is named,
because a port that reproduces the code without the reason will drop the rule the first time it is
inconvenient.*

## 1. The measurement, exactly

**The unit measured** is one cold app launch of the ExampleApp benchmark build, captured as a perfetto
trace by androidx macrobenchmark. Every number in the project is derived from the trace — never from
logcat, never from the benchmark's own JSON — because only the trace can be re-queried later.

**The window** is the SDK-init interval reported per launch. Two definitions exist and the difference
matters:
- `emb-sdk-start` — the section wrapping the whole `Embrace.start()`. **Exists only from 9.2.0.**
- **Composed** — from the start of `emb-modules-init` to the end of `emb-post-services-setup`. Exists
  in every version measured, and is therefore **the metric of record for anything cross-version**.
  It is a *subset* of `Embrace.start()` (19 instrumented sections lie outside it), so it understates
  total init cost. The SQL prefers `emb-sdk-start` and falls back to composed; the longitudinal store
  is defined on composed.

**Sections** are the `emb-*` trace slices the SDK emits around each init phase. Each section is taken
as its **first occurrence** by timestamp (several legitimately recur; only the init-path instance is
the one being measured). Sections **nest** — `modules-init` contains `config-service-init`,
`span-service-init` (which contains `otel-tracer-init`), `essential-service-init`, and at 9.2.0
`persisted-config-load` — so **section deltas are never additive** and must never be summed into "share
of the gain". An earlier report printed "top 8 = 194% of the gain" by doing exactly that.

**Cross-version section comparison by NAME is unreliable across 9.0.0 → 9.2.0**: that step renamed
spans from minified class names (`emb-mb0-init`) to literals (`emb-persisted-config-load`), so 25
names exist only in the old and 19 only in the new. Containment must be measured from intervals, not
inferred from names, and separately for each version.

## 2. The run shape, and why it is part of the key

**Standing design: 10 passes × 20 iterations per arm**, each pass from an independent install. This
is not a precision choice; it is a **definitional** one:

- Launches within a pass are clustered (shared install, thermal state, background churn). Between-pass
  variance dominates the *arm estimate* on this fleet (93–99% on the A14 at 4×50), so only pass count
  buys precision at a fixed launch budget; iterations inside a pass buy almost nothing.
- **Pass count changes what is measured, not just how precisely.** Changing shape moved medians
  device-dependently (Pixel 3 −10 to −19%, A14 +10 to +17%). A 4-pass follow-up to a 10-pass series
  *inverted* the device ordering it was meant to explain (X34). **Run shape is therefore a field of
  the recipe key**, like the instrument, and results are never compared across shapes.
- The permutation floor at 4 passes per arm is 2/C(8,4) = 0.029 — a design that can never report
  p < 0.029 regardless of effect. At 10 it is 1.1×10⁻⁵.

**The store's ingest enforces shape**: a run with fewer than 90% of `passes × iterations` windows is
refused as truncated (the missing passes are the later, warmer ones); a run with more than 110% is
refused as over-long (a 10×50 leg once entered a 10×20 series with rc=0 and the only symptom was
`n=500` in a log line — the over-long direction is the dangerous one because it looks like unusually
good data).

Where the Python disagrees with itself about shape (4×50 in two SKILL.md files, 10×20 in two others,
4×50 in `plan-example.json`), **10×20 is the current standard** and the port should say so once.

## 3. Statistics — the method of record

**Unit of evidence is the pass, never the launch.** All inference is clustered:
- **Interval on a difference:** two-stage cluster bootstrap — resample passes with replacement within
  each arm, recompute the statistic on the pooled launches, take the 2.5/97.5 percentiles of the
  difference. Seeded.
- **p-value:** cluster permutation — relabel whole passes between arms, count arrangements at least as
  extreme; report `min_attainable_p = 2/C(total, per-arm)` beside every p so a floor is never read as
  a strong result.
- **Verdict rule:** the CI-excludes-zero criterion is the gate the published tables verdict on. **When
  CI and p disagree, report "suggestive", never "supported"** — seen live at p=0.014 with CI
  [−16.24, +0.27].
- **Three statistics together, always:** median, p90, p95, each with absolute *and* percentage delta
  and CI. The tail follows a power gradient (median → p90 → p95) that must be reported as power, not
  inconsistency. p99 is suppressed below n=500.
- **Refuse pass-level inference when n ≠ passes × iterations**: pass boundaries recovered positionally
  from a flat window list misalign on any dropped trace; such arms are reported level-only.
- **Design effect / ICC** are computed per arm and reported; "93–99% between-pass" is the estimator
  split on one device/version and is **not** a fleet constant — the raw ICC on the same 200 launches
  can read 0.027. Always say which decomposition a number is.
- **Effect size** is Cliff's delta / A12 (ordinal; skew-robust), with a caveat that clustering
  inflates it. **Equivalence** is TOST against a declared margin (the ±4% noise band). **Multiple
  comparisons** use Benjamini–Hochberg, declared before testing — and BH once let a wrong test
  through, so a corrected test is still not a right test.

**A known inconsistency the port must resolve:** the Python has **three incompatible quantile
definitions** (index-based `v[int(p·n)]` in the stores and reports, a rounded variant in
`hypothesis_tests`, and Type-7 interpolation in `stats.py`). The published version tables were computed
with the index-based one. The port must pick one, document it, and re-derive any published number it
changes — or preserve the index-based one for store-derived figures and label it.

**`stats.py` is the method of record and is imported by nothing.** Every report script hand-rolls its
own comparison. The port should make the shared statistics library the *only* implementation.

## 4. Validity before statistics — the guards

Each of these exists because its absence produced a wrong number that looked right.

1. **Verify every leg against the device crash buffer, never the harness exit code.** One device
   produced 200 green, complete, plausible traces from a process that crashed on every launch. Scope
   the check to the *app's* process (`Process: io.embrace.android.exampleapp`): an app crash
   invalidates a leg; a harness crash (`UiAutomation not connected!`) only aborts it, and a timeout
   kill can *manufacture* a harness crash that then poisons a completed leg.
2. **Trace health before any number**: perfetto loss counters × canary-slice presence, giving five
   verdicts (`ok / lossy / unusable / missing-canary / slices-incomplete`). `unusable` traces are dropped;
   buffer-loss share above 2% refuses the run; the signal inventory is taken only from a clean trace.
3. **Prove the arms differ before spending device time on an A/B.** Order of preference:
   (a) **verify which SDK the app resolves** — the ExampleApp pins `embrace = "<version>"` from
   mavenCentral, so a worktree at the commit under test *still builds a released SDK* unless the pin is
   repointed to a mavenLocal publish (X37 ran 22 clean legs on released 9.1.0 this way, 2.5 h void);
   (b) **the propagation gate** — the effect must concentrate in the sections the flag targets (OTel
   construction down 42–90%) while `otel-module` holds within ±7%; run it on the first leg pair and
   abandon the device if it does not fire; (c) artefact comparison is a smoke test only — Android builds
   are not byte-reproducible (275 dex byte differences for a paired build, 11,790 after independent
   rebuilds), so only *identical* dex is conclusive, and only of failure.
4. **A pre-registered control.** Design every follow-up to re-measure a quantity already established
   independently (e.g. a device's known median effect); reproducing it licenses reading the new
   statistic, and failing to reproduce it means the premise is unverified, not that the new statistic
   is null.
5. **Compare a run's level against the store to identify what was measured.** X37's pooled A14 median
   (61.21 ms) sat on the store's 9.1.0 record (63.02), not 9.2.0 (45.05); the store doubles as a
   provenance check.

## 5. Operational discipline for unattended campaigns

- **Worktrees, never the user's checkout**: `git worktree add --detach` at the commit under test;
  per-version resets are in-worktree; the checkout stays free. Probe a worktree by the presence of
  `examples/ExampleApp/gradlew`, not the directory — `/private/tmp` purges by file age and leaves
  gutted directory trees standing.
- **One Gradle campaign at a time, on a quiet host.** A second daemon (the user building) killed a leg
  with `NoClassDefFoundError: com/google/common/base/Stopwatch` inside AGP's UTP runner. Heavy
  `trace_processor` analysis counts as contention too; inference runs at ingest gaps.
- **Daemonize anything long** (`start_new_session=True`); harness background tasks get reaped. **Kill
  process groups** on timeout, then sweep the device (`am force-stop`, `pkill perfetto`, check for
  `tracebox`/`atrace`, `df /data`) — SIGTERM on the host leaves device-side tracers running, and one
  set held the ftrace buffer for 40 minutes producing silently empty traces.
- **Cool gate on silicon, never battery** (battery reads ~31 °C while CPU sits at 55 °C), relative to
  the device's own *settled* baseline; the A14's compile-parity toggle is a real bimodal state, not
  noise.
- **Legs are idempotent and resumable**: a leg whose output exists is skipped, so a killed campaign
  resumes by re-running the driver; timeouts are sized from measured pass rates (A01 ≈ 6–7 min/pass).
- **Borrowed state must be returned on kill.** Three layers: marker file (survives SIGKILL; recover
  *before* reading the current value), signal handlers that restore then re-raise under `SIG_DFL`, and
  `finally`. SIGTERM skips `finally`; two killed runs left a version pin dirty.
- **Reduce early, and reduce for the question after next.** Extract per-launch windows *and*
  per-section medians as each leg completes, write them to durable storage, then delete traces. A
  campaign that kept only medians made p90/p95 *unanswerable* later, and one that kept only windows
  could not run the propagation gate after the fact.

## 6. The data stores (the durable substrate the port inherits)

- **Longitudinal store** — `claude-output/longitudinal/store.jsonl`: one JSON record per run;
  `windows_ms[]` per launch; `derived{n, median, p90, p95, max, iqr}`; recipe
  `{build_type, compile_state, instrument, run_shape, trace_processor_version}`; `baseline_eligible`;
  `trace_health`. 12 records (9.0.0 ×4, 9.1.0 ×3, 9.2.0 ×4) plus a sweep store of 4 (8.3.0 ×4) — the
  complete 4-version × 4-device matrix at 10×20.
- **Reference set** — `reference-set.json`: the device keys (`flagship-a`, `mid-a`, `mid-b`,
  `entry-a`), their profiles (drift is checked at ingest), and the frozen recipe with `instrument`
  deliberately null until set.
- **Section medians** — `2026-08-25-x35-attribution-10x20/*.json`: per device/version
  `{"medians": {section: ms, "__window__": ms}}`, the input to attribution and containment work.
- **Per-leg arrays** — `2026-08-26-x37-engine-tail/*.json`: per leg `windows_ms[]` (+ `section_medians_ms`
  in the fixed driver). *This particular set is void; the format is the one to keep.*

These are the **parity fixtures**: every analysis the Python performs on them can be re-run in Kotlin
against identical inputs and diffed.

## 7. The documents, and the rule about updating them

Living HTML documents in `claude-output/` are published as artifacts; the two copies drift in **both**
directions (a local update never republished for nine days; published banners never saved locally
that an edit would have deleted). Rule: **always reconcile before updating; the published copy is the
truth unless you know you changed the local one since you last reconciled.** `artifact_sync.py` makes
"unless you know" mechanical (UNKNOWN / CLEAN / DIRTY against a manifest of publish digests). Tables,
prose and the provenance stamp change together, never separately. Numbers in a doc are labelled with
the SDK version they describe; the durable form of a finding is a ratio within one version across
device classes.

## 8. What is genuinely settled (do not re-derive)

- Tier span is ≈8× and stable across versions (8.5× at 8.3.0, 8.0× at 9.2.0) while both ends halved.
- 8.3.0 → 9.2.0 at the median: −44.9% / −26.5% / −40.4% / −47.7% (P7P / Pixel 3 / A14 / A01), all
  supported with intervals at 10×20; the Pixel 3's shortfall on 9.0.0 → 9.2.0 is ~79% one phase
  (`post-services-setup`).
- The otel-kotlin engine at the 08-17 snapshot: −20.4% / −17.7% / −15.1% on A14 / Pixel 3 / A01 at
  the median, −4.3% on the flagship, propagation-gated per device. **Its tail is unmeasured**, and
  whether it helps at all on released 9.1.0 is open.
- `emb-persisted-config-load` is the largest direct child of the biggest in-window phase on every
  device (6.0 / 13.0 / 20.8 ms); `modules-init`'s apparent growth across the rename boundary is a phase
  shift, not concealed cost (residual explains 4–12%).
- Compile state (install-time AOT) is worth up to 2× on the window and ±45% at TTID and is a device
  fact, not ours; core count, charging state, CPU clock per se, `init-maj-faults` as a proxy, and the
  ART-12 profile inversion are refuted.
