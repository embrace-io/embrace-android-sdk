# VOID — this data does not answer the engine question

**These 22 legs benchmarked the RELEASED 9.1.0 SDK in both arms.** They are not a compat-vs-kotlin
comparison, and no engine conclusion may be drawn from them.

The ExampleApp pins `embrace = "9.1.0"` and resolves from mavenCentral, so both worktrees built
against a published release rather than the code under test. Flipping
`sdk_config.otel.enable_otel_kotlin_sdk` changed a setting inside an SDK that was never the subject.

**How it was caught:** the pre-registered control failed. X33 measured −20.4% on the A14; these legs
return **+0.1% at the median (p=0.97)**. Two independent confirmations followed — an arm-vs-arm check
on the Pixel 3 (`../2026-08-26-x37-arm-reality-check/`) at **+2.4%** where X33 measured −17.7%, and a
level check: the pooled A14 median of **61.21 ms** lands on the longitudinal store's **9.1.0 record
(63.02 ms)**, not 9.2.0 (45.05) or 9.0.0 (69.62).

## What these files *are* legitimately good for

- **A cross-provenance replication of 9.1.0 on the A14**: 400 launches, agreeing with the store's
  9.1.0 record to within 3% under a different build provenance. That is a real validity check of the
  measurement chain, of the same kind X33 produced by accident.
- **Nothing else.** In particular the per-launch tails here describe 9.1.0, not the engine.

## Open question these files cannot settle

Why the flag was inert on 9.1.0 is **not established**. The flag *is* wired at tag `9.1.0` —
`OtelBehaviorImpl.shouldUseKotlinSdk()` is consumed by `OpenTelemetryModuleImpl` — so either the
Kotlin engine gives no startup win at that release (which would make X33's win a property of
post-9.1.0 code, a genuine finding) or the injection did not take (making the null an artefact).
Deciding it needs one propagation-gated leg; it cannot be done from these files, because the driver
discarded the per-section rows and deleted the traces.

*Written 2026-08-26 when the run was stopped at entry-a leg 5. Full write-up: the testing log entry
for X37, and the tracker's X37 row.*
