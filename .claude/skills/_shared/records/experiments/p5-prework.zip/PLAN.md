# P5 prework: cheap prod metadata, no new plumbing (2026-08-13)

Everything below rides the existing `attributesProvider` composition in `markSdkInitComplete`
(tracker deltas + record-time environment reads). No interface changes, no new modules, no new
threads. Files in this directory are ready-to-paste code; swap-in order at the bottom.

**REBASED 2026-08-13 (2nd pass) onto the simplified architecture:** the env-attrs function no
longer takes a raw Context — system services come through the memoized
`InstrumentationArgs.systemService()` accessor (PowerManager AND the new ActivityManager for
memory info, both wired as provider lambdas at the `markSdkInitComplete` call site), and
package info is a plain `PackageInfo?` value: `InstrumentationArgs.packageInfo` holds the
SDK's single `by lazy` memoized lookup (no wrapper class, no CoreModule involvement — both
were removed in review; args owns it because args-layer consumers are the only ones).
Resolving it at the call site triggers the one binder call off the hot path.
`EmbraceMetadataService` needs no package info at all — `context.packageName` is a free field
read (its redundant binder lookup was removed as its own commit). Exact call-site wiring at
the top of `02-environment-attributes-full.kt`. Const-naming note: this file's existing consts use the
`_ATTR` suffix, the tracker's don't — new ones are suffix-less, harmonize at review.

## Attribute inventory

### Window-delta attrs → `SdkInitMetadataTracker` (captured at both edges, computed in buildAttributes)

| attr | source | units | outlier class served | hot-path cost |
|---|---|---|---|---|
| `init-maj-faults` | `/proc/self/stat` majflt delta | count | B (flash IO / page faults incl. install-aftermath storage contention) | +1 procfs read/edge (~0.1 ms) |
| `init-disk-read-kb` | `/proc/self/io` read_bytes delta | KB | B (actual storage reads during init: cold config/odex/page-ins) | +1 procfs read/edge (~0.1 ms) |
| `init-gc-count` | `Debug.getRuntimeStat("art.gc.gc-count")` delta | count | D (own-process memory pressure — 64–99 ms GC inside half of Go-tier outlier windows) | ~µs JNI call/edge |
| `init-gc-time-ms` | `Debug.getRuntimeStat("art.gc.gc-time")` delta | ms (absolute, NOT pct — process-wide and largely concurrent, so it must not be confused with the thread-scoped pct scheme) | D | (same call) |
| `seconds-since-boot` | already-captured `startWallMs` (elapsedRealtime) | s | E-adjacent (recent reboot = cold caches + post-boot dexopt/system activity) | FREE (already captured) |

Hot-path budget after additions: 2 clock syscalls + 4 small procfs reads + 2 runtime-stat JNI
calls per edge ≈ **0.5 ms worst-case total**, still "negligible" class; document in the PR.

### Record-time attrs → `sdkInitEnvironmentAttributes` (binder/sysfs allowed, runs once, memoized)

| attr | source | units | purpose | notes |
|---|---|---|---|---|
| `mem-available-pct` | `ActivityManager.getMemoryInfo` availMem/totalMem | whole % | D cohorting (tier-free) | one binder |
| `low-memory` | same call, `lowMemory` flag | emitted only when "true" | D flag | free |
| `psi-cpu-some-avg10` | `/proc/pressure/cpu` first line avg10 | as reported (e.g. "1.23") | A (device-wide pressure over last 10 s ≈ the init window) | feature-detected: silently absent where SELinux denies (common) |
| `soc-model` | `Build.SOC_MODEL` (API 31+) | string | THE primary cohort key (device performance model) | omit if blank/"unknown" |
| `soc-manufacturer` | `Build.SOC_MANUFACTURER` (API 31+) | string | cohort key | same |
| `cpu-max-freqs-khz` | sysfs `cpufreq/policy*/cpuinfo_max_freq` | distinct sorted CSV, e.g. "1800000,2400000" | cluster topology for pre-31 devices + cross-check | world-readable sysfs; feature-detected |
| `cpu-core-parts` | `/proc/cpuinfo` distinct "CPU part" values | CSV, e.g. "0xd05,0xd4b" | microarchitecture (big-core arch) — the causal term core count misses | readable app-side; ~KB read, record-time only |

> **UPDATE (2026-08-14): `psi-cpu-some-avg10` was implemented, measured, and REMOVED.** It shipped
> 2026-08-13 (commit `011d73e72`) and was measured across the full 4-device fleet (Pixel 7 Pro API
> 35, Galaxy A14 API 35, Pixel 3 API 31, Galaxy A01 Core API 29 — two vendors, three API levels) —
> it populated on **0/54 launches**. The row's "feature-detected: silently absent where SELinux
> denies (common)" framing above undersells the cause: this is not a per-vendor gap. AOSP labels
> `/proc/pressure/cpu` with its own SELinux type (`proc_pressure_cpu`, via a `genfscon` entry in
> `system/sepolicy/private/genfs_contexts`) and grants read access only to the `lmkd` and
> `system_server` domains — no app domain has ever had it, on any OEM tested, back to Android 10.
> The file reads fine via `adb shell` (misleading — that domain keeps broad legacy `/proc` access);
> only `run-as <pkg> cat /proc/pressure/cpu` (Permission denied) tests real app-side readability.
> There is no app-readable device-wide CPU-contention signal at all as a result —
> `init-run-delay-pct` is the only one available, and it is independently verified accurate (within
> 0–2 points of trace ground truth across 54 graded iterations). Confidence: high but not absolute
> (no counterexample found on Google/Samsung; further OEMs would corroborate further). The
> attribute has been **removed from the SDK** — the row above and the code sample in
> `02-environment-attributes-full.kt` are kept as a historical record only; do not re-add it without
> solving app-side unreadability first. Full analysis in `claude-output/startup-testing-log.html`
> and the P5 row of `claude-output/startup-improvements-tracker.html`.

Device manufacturer/model/Android version are ALREADY in the payload's device metadata — not
duplicated here.

## Deliberately excluded (say why in the PR)

- **Compile state** (the SPEG/install-dm dimension): no public in-app API for own dexopt status.
  Highest-value missing attr; needs its own investigation (possible heuristics: odex file
  presence via classloader paths — out of "cheap" scope).
- **Core placement** (`cpus_seen`/`min_core_class`): two-point sampling at the edges is
  misleading; doing it right needs in-window sampling = new plumbing. Run-delay already captures
  the consequence.
- **`/proc/stat` global CPU**: SELinux-blocked API 26+ (established 2026-08-12).
- **minflt**: dominated by normal allocation; majflt is the diagnostic one.

## Parsing hazards handled in the code

- `/proc/self/stat`: the comm field `(...)` can contain spaces and even `)` — parse from the
  substring AFTER THE LAST `)`; post-paren token index 9 = majflt (field 12 1-indexed).
  Test fixture uses a comm with a space and parens to pin this.
- `/proc/self/io`: line-keyed (`read_bytes: N`); tolerate missing lines/kernel variants.
- `Debug.getRuntimeStat` returns strings; missing/renamed keys → null → attr omitted (same
  omission contract as schedstat).
- cpufreq/cpuinfo reads: any failure → attr absent; never partial garbage.

## Test plan (fixtures included in 03-tests-additions.kt)

Tracker: majflt delta via realistic stat lines (comm with spaces/parens boobytrap), read_bytes
delta, gc count/time deltas via injected runtimeStat lambda, seconds-since-boot from the wall
fixture, each source's absence omitting only its own attrs. Environment: Robolectric —
ShadowActivityManager memory info (pct + low-memory-only-when-true), SOC gating below/above
API 31, psi/cpufreq absence tolerated (no /proc/pressure on host).

## Swap-in order (when the tree is yours again)

1. `01-tracker-additions.kt` — labeled insertion blocks for `SdkInitMetadataTracker.kt`
   (rebase note: written against the state where consts are `INIT_CPU_PCT`/`INIT_RUN_DELAY_PCT`
   and `wholePercent` is the float version; if your in-flight edits moved things, the blocks are
   small and self-contained).
2. `02-environment-attributes-full.kt` — full replacement for `SdkInitEnvironmentAttributes.kt`
   (current file content is embedded unchanged; additions marked with `// P5:` comments).
3. `03-tests-additions.kt` — test methods for both test files + fixture constants.
4. Run: `:embrace-android-instrumentation-startup-trace:testDebugUnitTest` + `detekt`.
5. Docs sweep afterwards (recommendations doc P5 row → implemented; testing log entry; primer
   untouched). I'll do this on request post-commit, together with the -pct rename sweep.
