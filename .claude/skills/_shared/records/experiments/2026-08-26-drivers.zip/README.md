# Drivers preserved 2026-08-26

Copied out of the session scratchpad, which `/private/tmp` purges periodically.

- `x40_engine_tail.py <version>` — the engine-tail redo. Refuses to start unless the SDK
  under test is in mavenLocal, BOTH worktrees pin it, and the flag is split across arms;
  then abandons any device whose propagation gate does not fire on the first leg pair.
- `x37_analyze.py` — median/p90/p95 with pass-level clustering over preserved legs.
- `arm_reality_check.py` — compares two APKs via the verification tap's per-launch
  `emb-embrace-init` durations. No gradle, no perfetto; usable while the host is busy.
- `repoint_pins.py <version>` — repoints the ExampleApp version pin in both worktrees and
  asserts the plugin declaration survives.
- `which_version_did_x37_measure.py` — compares a run's level against the longitudinal
  store to identify which SDK was actually measured.

Paths inside these scripts point at the session scratchpad. If it has been purged, the
worktrees they expect are gone too and must be recreated with `git worktree add --detach`.
