# Is `emb-modules-init`'s regression genuine, or re-attribution?

**Answer: neither, as posed.** The span really does take longer — +16% to +36% across three devices,
while the composed window improves 29–35% over the same step. But it is not concealing new cost, and
it is not a like-for-like comparison either. It is a **phase shift wrapped in a naming
discontinuity**, and the two have to be separated to say anything true about it.

*Analysis 2026-08-26. Structure measured from X35's surviving traces; durations from X35's 200-trace
medians. Data and script: `rename-map-results.txt`, `rename-map-raw.json`, `rename_map.py` in this
directory. No new device runs were needed.*

## The measurement

`emb-modules-init`, 9.0.0 → 9.2.0, with the window alongside for scale:

| device | modules-init | change | window | residual (unnamed part of the span) |
|---|---|---|---|---|
| entry-a (A01 Core) | 62.43 → 84.63 ms | **+35.6%** | 145.68 → 94.46 ms (−35.2%) | 4.79 → 7.48 (**+2.69**) |
| mid-a (A14) | 35.41 → 42.67 ms | **+20.5%** | 71.00 → 47.06 ms (−33.7%) | 1.81 → 3.38 (**+1.57**) |
| mid-b (Pixel 3) | 25.38 → 29.47 ms | **+16.1%** | 49.77 → 35.19 ms (−29.3%) | 1.40 → 1.90 (**+0.51**) |

The **residual** is the part of `modules-init` that no named child accounts for. It is the number
that decides the question, and it barely moves: it explains only 4–12% of the span's growth. Whatever
`modules-init` is now spending, it is spending inside spans that have names.

## Why the span is not comparable across the step

Its direct children are almost entirely replaced — 14 added against 14–15 removed, with only **one or
two kept** on any device:

| | entry-a | mid-a | mid-b |
|---|---|---|---|
| added / removed / kept | 14 / 14 / 2 | 14 / 14 / 2 | 14 / 15 / 1 |
| added children total | +45.85 ms | +23.37 ms | +16.02 ms |
| removed children total | −30.42 ms | −18.63 ms | −12.11 ms |
| kept children drift | +4.08 ms | +0.95 ms | −0.33 ms |
| residual change | +2.69 ms | +1.57 ms | +0.51 ms |

Every removed name on every device is an R8-style short name — `emb-mb0-init`, `emb-wh0-init`,
`emb-vt4-init`, `emb-ed3-init`, `emb-s51-init`, `emb-q21-init`, `emb-ve0-init`, `emb-nq0-init`,
`emb-o35-init`, `emb-of2-init`, `emb-w91-init`, `emb-dz1-init`, `emb-fc5-init` — plus
`emb-event-service-init`. Every added name is a literal: `emb-persisted-config-load`,
`emb-delivery-init`, `emb-config-init`, `emb-payload-source-init`, and so on.

That is the signature of spans named from **minified class names** in 9.0.0 being given **explicit
literal names** in 9.2.0. **X34 already recorded this** — its finding (2) names the boundary as "25
sections only in 9.0.0 (obfuscated `emb-dz1-init`…), 19 only in 9.2.0 (readable `emb-config-init`…)"
— so the observation is not new here. What is new is that it now covers `modules-init`'s **own direct
children specifically**, where all 14 removed names are minified and all 14 added ones are literals.
That upgrades the boundary from "a caveat on cross-version section tables" to a statement about this
span in particular: **its child set cannot be matched across the step by name at all**, so the
apparent wholesale replacement of its children is a labelling change and not evidence that the SDK
reorganised what runs inside it.

### One correspondence, offered as a hypothesis and not a conclusion

`emb-mb0-init` is the largest removed child on every device and `emb-persisted-config-load` is the
largest added one, at broadly similar size:

| device | `emb-mb0-init` (9.0.0) | `emb-persisted-config-load` (9.2.0) | ratio |
|---|---|---|---|
| entry-a | 22.26 ms | 20.81 ms | 0.94 |
| mid-a | 15.44 ms | 12.96 ms | 0.84 |
| mid-b | 8.84 ms | 6.03 ms | 0.68 |

It is tempting to call these the same work renamed. The evidence is only a **size correspondence
with the names stripped out**, the ratio is not tight (0.68 on mid-b), and nothing here rules out
two different pieces of work that happen to be the biggest on each side. Settling it needs the
mapping file or the source, not more traces.

## What the growth actually is

The window improved by 51.2 ms on entry-a while `modules-init` grew by 22.2 ms, so the phases outside
it improved by roughly 73 ms. Those phases are known from X35: `emb-post-services-setup` (−32.22 ms
on entry-a) and `emb-config-service-init` (−20.41 ms). Read together with a flat residual, the
consistent story is that **9.2.0 moved config work earlier — into `modules-init` — and made the later
blocking config phases dramatically cheaper**. Net inflow into the span scales with device slowness:
+3.9 ms on mid-b, +4.7 ms on mid-a, +15.4 ms on entry-a.

So the regression is real in duration, benign in effect, and **not** evidence of an unaccounted
slowdown.

## The actionable part

`emb-persisted-config-load` is the **largest single direct child of `modules-init` on every device** —
6.03 ms on mid-b, 12.96 on mid-a, 20.81 on entry-a, and on entry-a alone it is 22% of the whole
composed window.

**This is corroboration, not discovery, and the distinction matters for how much weight it carries.**
The span was already known and already the target: the P17-era engine data measured it at 17.41 ms,
and tracker item **P1** is written around it explicitly (its overlap scoping is phrased in terms of
"`persisted-config-load`'s current slot"). What X38 adds is *where it sits and how much of the phase
it owns* — it is the biggest thing inside the biggest in-window section, on every device, at 9.2.0 —
which raises confidence in P1's priority rather than creating a new item. It is also the natural
first thing to check if a later version's window regresses.

## Caveats

- **Structure and level come from different sources on purpose.** Containment is a property of the
  code path and is stable in a 4-trace sample; a duration median is not. The first run of this
  analysis took both from the same four traces of `pass1` and produced an entry-a `modules-init` of
  100.77 ms against a 94.46 ms window — impossible for a span the window encloses, and the tell that
  the sample was drawn from the pass most distorted by install aftermath.
- **Containment is not perfectly stable trace to trace.** `emb-sdk-disable-check` is a direct child
  on mid-b at 9.0.0 but not at 9.2.0, and `emb-span-service-init`'s direct-child status varied
  between the two samples taken here. Children are counted only when the relation holds in every
  sampled trace, so instability shows up as a dropped child rather than a wrong number — but it
  means the added/removed counts carry roughly ±1.
- **Only the direct-child layer is priced.** `emb-config-service-init` does not appear in these
  tables because it nests deeper (under `emb-config-init`), so this accounting says nothing about it.
- **Three devices, not four.** X35 did not run the flagship, so the flagship's `modules-init` is
  uncharacterised here.
