# 4×50 series: store destroyed 2026-08-16 08:29, salvaged aggregates only

**The 4×50 `store.jsonl` (8 records) no longer exists and cannot be recovered.**

## What happened

`combined_campaign.py` archived the previous series on startup with an unconditional
`STORE.replace(ARCHIVE / "store.jsonl")`. That is correct on a first run. On the **restart** at
08:29 — launched to re-run the two failed `entry-a` legs — the live store held *this* run's six
10×20 records, so the move displaced them **on top of** the eight 4×50 records, overwriting them.

The 4×50 raw traces had already been pruned at 03:00 to free disk (they were reduced into exactly
this store, which is why deleting them was judged safe). With both the store and its traces gone,
the per-launch data is unrecoverable.

This was a half-finished repair. At 02:22 the same restart hazard was identified and the
**reference set** was guarded against re-archiving — but the store's move was left unguarded, and
the fix was reported as complete. The guard now exists for both (`archived_store.exists()` is the
marker that the one-time move already ran).

## What is lost

Per-launch `windows_ms` for all 8 arms — 1,600 individual measurements. Any *new* analysis of the
4×50 series is impossible; only the numbers already computed survive.

## What survives, and from where

Aggregates below were printed during analysis before the overwrite. Recipe for every arm:
`4×50, benchmark, compile_state=profile, instrument=composed`. n=200 except the flagship arms,
which held n=199 (one trace dropped at ingest — the reason `shape_analysis.py` skipped them rather
than mis-chunking 199 into 4 passes of 50).

| device | version | median | p90 | IQR | CI half | betweenSD | withinSD | drift | pass median range |
|---|---|---|---|---|---|---|---|---|---|
| flagship-a | 9.1.0 | 17.512 | — | 3.804 | n/a (n=199) | — | — | — | — |
| flagship-a | 9.0.0 | 19.382 | — | 3.236 | n/a (n=199) | — | — | — | — |
| mid-b | 9.1.0 | 46.845 | 49.064 | 8.912 | 4.55 | 3.87 | 2.64 | +3.27 | 38.5–47.8 |
| mid-b | 9.0.0 | 47.291 | 53.233 | 7.307 | 3.82 | 3.60 | 2.63 | +3.23 | 43.3–52.4 |
| mid-a | 9.1.0 | 53.943 | — | 8.832 | 4.55 | 4.34 | 5.26 | −2.92 | 50.9–62.0 |
| mid-a | 9.0.0 | 63.293 | — | 15.324 | 7.60 | 7.65 | 5.65 | −3.06 | 54.4–70.8 |
| entry-a | 9.1.0 | 121.535 | — | 19.119 | 2.13 | 2.11 | 15.18 | −4.39 | 118.6–124.1 |
| entry-a | 9.0.0 | 143.673 | — | 17.605 | 1.91 | 1.96 | 14.48 | −6.46 | 142.0–146.9 |

`CI half` = 95% cluster-bootstrap half-width on the arm median, resampling passes.
`drift` = mean(last third of a pass) − mean(first third), ms; positive = slows within a pass.

Device profiles for all four devices survive in this directory's reconstructed
`reference-set.json`, recovered from the store's own records before the overwrite.

## What this does and does not cost

The two conclusions drawn from this series are **already computed and unaffected**: the shape
comparison (10×20 cuts the CI half-width 45–95%) and the within-pass drift mechanism (sign is
device-specific — `mid-b` heats, `mid-a` and `entry-a` warm up). Both are recorded in the table
above and in the testing log.

What is gone is the ability to ask the 4×50 data anything *new* — a different estimator, a
different clustering, per-pass ordering effects. If such a question arises, the series would have
to be re-collected.
