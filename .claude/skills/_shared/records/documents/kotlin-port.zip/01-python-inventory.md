# Startup-Analysis Skill Suite — Port Inventory

*Produced 2026-08-26 by a full read of every `.py`, `.sql`, `SKILL.md` and `references/*.md` under
`.claude/skills/startup-*` and `.claude/skills/_shared`. This is the file-level record of what exists;
the companion `02-methodology-to-replicate.md` is the conceptual record of what the code encodes.*

Root: `<repo>/.claude/skills/`

## 0. Headline numbers

| Metric | Value |
|---|---|
| Python files | 19 (5 in `_shared`, 14 in skill `scripts/`) |
| **Total Python LOC** | **5,002** (`_shared` 1,011 + scripts 3,991) |
| SQL files | 5, **392 LOC** |
| SKILL.md files | 5, 869 LOC |
| `references/*.md` | 12 files, 2,100 LOC (+ 1 HTML template, 250 LOC) |
| `_shared/*.md` | 2 files, 471 LOC |
| **Third-party Python deps** | **NONE — every file is stdlib-only.** Verified by grepping every `import`/`from` line. |
| External binaries invoked | `trace_processor`, `adb`, `gradlew`, `git`, `pgrep` |
| Network endpoint | `https://get.perfetto.dev/trace_processor` (via `urllib.request`) |

**Distinct stdlib modules used** (relevant to a port): `argparse, contextlib, csv, collections.defaultdict, datetime, hashlib, http.server, io, json, math, os, pathlib, random, re, secrets, shutil, signal, stat, statistics, subprocess, sys, tempfile, time, urllib.request, zipfile`.

---

## 1. `_shared/` — the reusable core

### 1.1 `_shared/stats.py` — 428 lines
Statistical inference primitives designed for clustered, right-skewed startup data. **No CLI, no `__main__`.** Pure stdlib (`math`, `random`, `statistics`). **Imported by nothing** — see §7.

| Public symbol | Description |
|---|---|
| `MIN_CLUSTERS_PER_ARM = 4` | Floor below which cluster inference is reported unavailable. |
| `DEFAULT_RESAMPLES = 10000` | Default bootstrap/permutation resample count. |
| `QUANTILE_MIN_N = {0.90:100, 0.95:200, 0.99:1000}` | Minimum n before a quantile CI is shown. |
| `quantile(sorted_values, p)` | Type-7-style linear-interpolation quantile. |
| `quantile_support(n, p)` | How many observations sit beyond a quantile (`round(n*(1-p))`). |
| `quantile_ci_trustworthy(n, p)` | Whether a bootstrap CI for that quantile is worth showing. |
| `icc_oneway(clusters)` | Intra-class correlation from a one-way random-effects decomposition. |
| `design_effect(clusters)` | Returns `{icc, deff, n, n_effective}`; `DEFF = 1 + (m-1)*ICC`. |
| `cluster_bootstrap_diff(a,b,statistic,p,resamples,alpha,seed=12345)` | Two-stage cluster bootstrap CI for the difference (b−a); returns `available:False` + reason below 4 clusters/arm. |
| `cluster_permutation_test(a,b,statistic,p,resamples,seed=12345)` | Permutation test reassigning whole clusters; reports `min_attainable_p = 2/C(total, len(a))`. |
| `cliffs_delta(a, b)` | Cliff's delta + A12 + magnitude label (Romano thresholds 0.147/0.33/0.474). |
| `cliffs_delta_caveat(icc)` | Prose caveat on clustering inflation of the effect size. |
| `tost_equivalence(a,b,margin_pct,...)` | Equivalence test as bootstrap-CI inclusion inside ±margin. |
| `benjamini_hochberg(p_values, alpha=0.05)` | FDR control; returns per-index boolean verdicts. |
| `required_n(cv_pct, effect_pct, power, alpha, deff)` | Iterations/arm needed for an effect. |
| `min_detectable_effect(n_per_arm, cv_pct, power, alpha, deff)` | Smallest detectable difference. |
| `n_for_quantile(sigma_log, p, rel_precision, deff, confidence_z)` | Sample size for a quantile of a log-normal. |
| `n_for_exceedance_rate(rate, abs_precision, deff, confidence_z)` | Sample size for an exceedance rate. |
| `cuped_variance_reduction(pre_post_correlation)` | `{variance_removed: rho², n_multiplier: 1-rho²}`. |
| `_ndtri(p)` | Inverse normal CDF, Acklam rational approximation (private but load-bearing). |
| `sigma_from_quantile_ratio(p90_over_p50)` | `ln(ratio)/1.2815515655446004`. |
| `dilution(component_share_pct, component_change_pct)` | Component change expressed against the whole. |
| `practical(diff_pct, noise_band_pct)` | Does the difference clear the noise band. |
| `compare(a_clusters, b_clusters, label_a, label_b, noise_band_pct=4.0, quantiles=(0.90,0.95))` | The standard comparison bundle: n, clusters, medians, design effect, effect size, bootstrap CI, permutation test, per-quantile block. |

**Notable algorithms:** cluster bootstrap (two-stage), cluster permutation test with mirror-image p-floor, one-way ICC/DEFF, Cliff's delta/A12, TOST equivalence, Benjamini–Hochberg, power/sample-size formulas, Acklam inverse-normal.

### 1.2 `_shared/tooling.py` — 130 lines
Resolves/fetches/pins `trace_processor`. Has a `__main__` that prints the resolved path and the cache search order (no argparse).

| Public symbol | Description |
|---|---|
| `TRACE_PROCESSOR_VERSION = "v46.0"` | The pin. Bumping it is declared a recipe change. |
| `TRACE_PROCESSOR_URL = "https://get.perfetto.dev/trace_processor"` | Download source. |
| `CACHE_DIR_NAME = "embrace-startup-tools"` | Cache dir name. |
| `repo_root()` | `git rev-parse --show-toplevel` from this file's dir; fallback `parents[3]`. |
| `candidate_cache_dirs()` | Ordered: `$STARTUP_TOOLS_DIR`, `$XDG_CACHE_HOME`/`~/.cache` + `embrace-startup-tools`, `<repo>/.claude/skills/.tools`. |
| `tool_path(name, version)` | `<cache>/<name>/<version>/<name>`; first existing, else first writable. |
| `ensure_trace_processor(explicit=None, version=..., quiet=False)` | Returns a runnable path, downloading via `urllib.request.urlopen(..., timeout=120)` into a `.partial` then `replace`, then `chmod +x` (S_IXUSR|S_IXGRP). |
| `tool_provenance(path=None, version=...)` | `{trace_processor_version, trace_processor_path}` for recording with results. |

**Subprocess:** `git rev-parse --show-toplevel` (timeout 60).
**Cache paths (environment-derived):** `~/.cache/embrace-startup-tools`, `$XDG_CACHE_HOME/embrace-startup-tools`, `$STARTUP_TOOLS_DIR`, `<repo>/.claude/skills/.tools`.

### 1.3 `_shared/trace_health.py` — 228 lines
Detects perfetto data loss before any number is trusted. Has a CLI.

**CLI:** `python3 trace_health.py <traces_dir> [--canary NAME (default "emb-sdk-start")] [--trace-processor PATH] [--show-meta]`
**Inputs:** recursively globs `*.perfetto-trace` and `*.pftrace` under `traces_dir`.
**Outputs:** stdout only — one line per non-`ok` trace, then `summarize()`.
**Subprocess:** `<trace_processor> -q <tmpfile.sql> <trace>` (timeout 900).
**Imports from `_shared`:** `tooling.ensure_trace_processor` (via `sys.path.insert` on its own dir).

| Public symbol | Description |
|---|---|
| `HEALTH_SQL` | One query: loss counters from `stats` (severity `data_loss`/`error`, value>0), canary slice count, total slice count, total sched rows. |
| `BUFFER_MARKERS` / `PARSE_MARKERS` / `META_MARKERS` | Substring lists bucketing perfetto counters by what they invalidate. |
| `classify(counter_name)` | Buckets a counter as `buffer`/`meta`/`parse`; unrecognised ⇒ `parse`. |
| `check_trace(tp, trace, canary="emb-sdk-start")` | Verdict dict: `ok` / `lossy` / `unusable` / `missing-canary` / `slices-incomplete`, plus `windows_ok`, `counts_ok`, `losses`, `buckets`, `slices`, `sched_rows`. |
| `summarize(verdicts)` | Multi-line prose summary with PREVENTION / CAVEAT / INVESTIGATE blocks. |
| `main()` | CLI entry. |

**Notable algorithm:** two-independent-checks design (loss counters × canary presence) with a 5-state verdict truth table; `_rows()` uses `tempfile.mkstemp` for the SQL file and parses CSV-ish stdout by splitting on `,` and stripping `"`.

### 1.4 `_shared/borrowed_state.py` — 90 lines
Context manager that restores shared mutable state (chiefly the gradle catalog SDK version pin) on normal exit, on signal, or on the *next* run. No CLI. **Imported by nothing** — see §7.

| Public symbol | Description |
|---|---|
| `BorrowedState(marker_path, read, write, log=print, signals=None)` | Context manager; default signals `SIGTERM, SIGINT, SIGHUP`. |
| `.recover()` | Restores a value left by a dead run; must run *before* reading current value. |
| `.restore(reason)` | Idempotent restore, safe from signal handler and `finally`. |
| `.__enter__()` / `.__exit__()` | Writes marker file, installs handlers, returns the original value; restores on exit. |

**Notable algorithm:** three-layer durability (marker file / signal handlers / `finally`), signal re-raise under `SIG_DFL` so exit status still reflects the signal.

### 1.5 `_shared/artifact_sync.py` — 135 lines
Drift guard for the "living docs" (local HTML vs published artifact).

**CLI (hand-rolled `sys.argv`, no argparse):**
- `artifact_sync.py check <local.html>` → exit 0 (CLEAN/DIRTY), 1 (UNKNOWN), 2 (MISSING)
- `artifact_sync.py record <local.html> <artifact-url> [<timestamp>]`
- `artifact_sync.py list`

**⚠ HARD-CODED ABSOLUTE PATH (the only one in the suite):**
`MANIFEST = <repo>/claude-output/artifact-manifest.json`

| Public symbol | Description |
|---|---|
| `digest(path)` | First 16 hex chars of SHA-256 of file bytes. |
| `load()` / `save(data)` | Manifest read/write (JSON, indent=1, sort_keys). |
| `key_for(path)` | Manifest key = file basename. |
| `check(path)` | UNKNOWN / CLEAN / DIRTY verdict. |
| `record(path, url, stamp)` | Records `{path, url, sha, published_at}`. |

### 1.6 `_shared/STATISTICS.md` — 410 lines
Companion prose to `stats.py`: bias vs variance, pass-as-unit-of-evidence, the 4-pass floor table, "spend the budget on PASSES", ICC gating, estimator mistakes, production quantile sample-size tables, GPD peaks-over-threshold, exceedance rates, CUPED, mSPRT, reporting checklist, and an evidence appendix with the four-device fleet measurements.

### 1.7 `_shared/living-docs.md` — 61 lines
Companion to `artifact_sync.py`: the reconcile-before-updating rule and the two real drift incidents.

---

## 2. `startup-analysis/`

**SKILL.md purpose (301 lines):** Run the SDK-init macrobenchmark on one connected device and report per-section durations, the SDK-init window, TTID, each section's share of the window, and a per-iteration main-thread scheduling readout — all derived only from `.perfetto-trace` files.

**Workflow:** 1) Pin the SDK version in `examples/ExampleApp/gradle/libs.versions.toml`. 2) Run `examples/ExampleApp/gradlew -p examples/ExampleApp :app:benchmark:connectedBenchmarkAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=io.embrace.android.benchmark.StartupBenchmarks -P…dryRunMode.enable=false`. 3) Collect traces from `…/connected_android_test_additional_output/benchmark/connected/<device>/`. 4) Fetch `trace_processor`. 5) `analyze_startup.py --trace-processor <path> "<traces dir>"`. 6) Optional `serve_trace.py` + `ui.perfetto.dev`. 7) Restore the catalog version.

Run shape policy stated here: **4 passes × 50 iterations** (4×25 floor) — *disagrees with the 10×20 mandated elsewhere; see §7.3.*

### 2.1 `scripts/analyze_startup.py` — 273 lines
- **Purpose:** aggregate SDK-init metrics across every iteration trace in a directory; print section, window, TTID stats and the contention table.
- **CLI (argparse):** `analyze_startup.py <traces_dir> --trace-processor PATH (required) [--all-sections] [--output-dir DIR] [--repo PATH]`
- **Inputs:** every `*.perfetto-trace` in `traces_dir` (non-recursive), sorted by `iter(\d+)`; sibling `startup_metrics.sql`.
- **Outputs:** stdout report and a copy at `<output-dir>/startup-analysis-<YYYY-MM-DD-HHMMSS>.txt`; default `<repo root>/claude-output`.
- **Subprocess:** `[tp, "-q", sql, trace]` (prefixed with `sys.executable` if `tp` is not executable); `git -C <script_dir> rev-parse --show-toplevel`.
- **`_shared` imports:** none (self-contained).
- **Notable:** `CANONICAL_SECTIONS` — 13 (name, nesting-depth) pairs in execution order; `CONTENTION_THRESHOLD = 0.15`; window-source consistency check (`emb-sdk-start` vs `composed` vs MIXED); "not instrumented in this SDK version" rather than zero; CSV parse keyed on the literal header `["what","k","val"]`, skipping `[NULL]`.

### 2.2 `scripts/serve_trace.py` — 28 lines
CORS-enabled static file server for `ui.perfetto.dev`. `serve_trace.py <dir> [port]` (default **9001**, bound to **127.0.0.1**).

### 2.3 `scripts/startup_metrics.sql` — 66 lines
Single UNION ALL statement; `INCLUDE PERFETTO MODULE android.startup.startups;`. **Schema read:** `slice`, `thread_track`, `thread_state`, `sched`, `android_startups`.

| `what` | `k` | `val` |
|---|---|---|
| `section` | slice name (`emb-*`) | duration ms of the FIRST occurrence |
| `window_ms` | `''` | window duration ms |
| `window_source` | `emb-sdk-start` or `composed` | 0.0 |
| `ttid_ms` | `''` | first `android_startups.dur`/1e6 |
| `wait_ms` | `''` | main-thread `R`/`R+` ms clipped to the window |
| `running_ms` | `''` | main-thread `Running` ms clipped to the window |
| `cpus` | `''` | distinct CPUs the main thread ran on in-window |

Window: prefers `emb-sdk-start`, falls back to `emb-modules-init` start → `emb-post-services-setup` end. Main thread = the track emitting `emb-modules-init`.

### 2.4 `scripts/init_window_sched.sql` — 27 lines
Standalone single-trace deep dive; **no Python driver**. Rows: `window_ms`, `thread_state_ms` by state, `cpu_residency_ms` by cpu. Window is the first `emb-modules-init` slice.

### 2.5 References
`interpreting-results.md` (583 — the foundational document: trace_processor traps, section placement, the telemetry verification tap, harness traps, run-condition recording, compile state, run shape and tails, five outlier classes, prod telemetry mapping, evidence appendix), `sections.md` (96), `confound-protocol.md` (85), `report-template.html` (250).

---

## 3. `startup-multi-device-analysis/`

**SKILL.md purpose (212 lines):** coordinated campaigns across a diverse device set, then comparison — flag differences, scope whose anomaly it is. A *flagging* layer, not an *attribution* layer.

**Workflow:** `device_probe.py` → `fleet_campaign.py` per device → `variance_analysis.py --json` per pass → `hypothesis_tests.py` per device → `outlier_factors.py` per pass → `factors_report.py` → `cross_device_sections.py` → condition arms → report.

### 3.1 `scripts/device_probe.py` — 303 lines
- `device_probe.py <serial> <name> <output-dir>` → `<output-dir>/<name>-topology.json`.
- **Subprocess:** `adb -s <serial> shell …` (timeout 15): chained `getprop`; `cat /proc/cpuinfo`; cpufreq `related_cpus`/`cpuinfo_max_freq`; `cat /proc/meminfo`; `ls /sys/block`; `dumpsys thermalservice`.
- **Notable:** `derive_clusters`, `compute_little_cpus`, `classify_ram` (<1536 go, <3072 low, <6144 mid, else high), `classify_storage` (`sd*`⇒ufs, `mmcblk*`⇒emmc), `classify_tier`, `parse_thermal_sensors`. `TRACING_API_FLOOR = 29`.
- **Emitted JSON keys:** `serial, name, vendor, model, android_release, api_level, soc_family, soc_model, clusters[], little_cpus, homogeneous, ram_mb, ram_class, storage_class, tier, thermal_sensors`.

### 3.2 `scripts/fleet_campaign.py` — 347 lines
- **CLI (positional):** `fleet_campaign.py <serial> <dir-match> <camp-dir> <passes> [method=coldStartup] [gap-after-pass] [--repo PATH]`
- **Outputs:** `<camp>/campaign.log`, `pass<N>-gradle.log`, optional `pass<N>-gradle-retry.log`, `<camp>/pass<N>/` (copytree of traces).
- **Subprocess:** `adb … dumpsys battery`; `adb … dumpsys thermalservice`; `<repo>/examples/ExampleApp/gradlew -p <app> :app:benchmark:connectedBenchmarkAndroidTest -P…class=…StartupBenchmarks#<method> -P…dryRunMode.enable=false -P…suppressErrors=LOW-BATTERY` with `ANDROID_SERIAL` in env; `git rev-parse --show-toplevel`.
- **Notable:** **cool gate** (`COOL_MARGIN_C = 8.0`, poll 30 s, max wait 900 s; gates on *silicon* via thermalservice, never battery; margin relative to the device's own settled baseline); `settle_baseline()`; **install-timeout retry** exactly once on `"Failed to install split APK"`; **resume** (skip existing pass dirs); `resolve_trace_dir()` normalises the dir-match hint and refuses to guess on multiple hits; `parse_silicon_temps()`.

### 3.3 `scripts/variance_analysis.py` — 243 lines
- **CLI:** `variance_analysis.py <tp> <traces_dir> [--json PATH] [--out PATH] [--little-cpus "0,1,2,3"]`
- **Outputs:** report sections A–E; `--json` = per-iteration `[{trace, window_ms, dur{}, cpu_ms{}, states{}}]` (the format consumed by `hypothesis_tests.py` and `cross_device_sections.py`).
- **Notable:** `CANONICAL` (13) + `EXTRAS` (5) + `SHORT` map (18); hand-rolled Pearson; top-7 deltas for the 4 slowest; thread-state split; little-share correlation.

### 3.4 `scripts/variance_metrics.sql` — 37 lines
Window = first `emb-sdk-start`. Rows: `window_ms`, `cpu_ms` per cpu, `dur` per `emb-*` slice, `st:<state>[+io]` per section.

### 3.5 `scripts/hypothesis_tests.py` — 206 lines
- **CLI:** `hypothesis_tests.py <campaign-dir>`; env `LITTLE_CPUS` (default `"0,1,2,3"`).
- **Inputs:** `pass1.json`…`pass19.json` (break on first missing) + `campaign.log` for battery temps.
- **Notable:** H1–H4 tests; thresholds `SLOW_DELTA_MS=4.0` (effective `max(4.0, 0.10*pass median)`), `CL0_MAJORITY=0.5`, `CL0_ABSENT=0.10`, `CFGLOAD_FAST_MS=5.0`, `POWER_STALL_MS=10.0`; `PURE_CPU` vs `BLOCK_RESUME` ratio fingerprint; hand-rolled `pctl` (a *different* quantile convention) and `pearson`.

### 3.6 `scripts/outlier_factors.py` — 62 lines
`outlier_factors.py <trace_processor> <traces-dir> <out.json>` → per-trace factor catalogue (consumers expect `passN-factors.json`). State keys folded as `"<state>[+io]" + (":" + blocked_function)`.

### 3.7 `scripts/outlier_metrics.sql` — 157 lines
Window = first `emb-sdk-start`. **Schema read:** `slice, thread_track, thread, process, sched, thread_state (io_wait, blocked_function), counter, cpu_counter_track, counter_track, process_counter_track, ftrace_event`. Rows: `window_ms, eff_mhz, run_cl0_ms/run_cl1_ms` (**fixed cpu<4 / cpu>=4 partition, deliberately not topology-aware**), `freq_cl0_mhz/freq_cl1_mhz`, `state:<state>[+io]` × blocked_function, `art_verify_ms, art_classload_ms, lock_contention_ms, binder_txn_cnt, gc_slice_ms, inproc` per thread, `othercpu` per process, `freq_limit_cl0/cl1, mem_swap, mem_available`. Requires `atrace_categories: "dalvik"` for GC slices.

### 3.8 `scripts/foreign_gc_overlap.sql` — 105 lines
**No Python driver.** Six paired ms/count buckets for GC-like work in *other* processes, reported separately so nothing is silently reclassified.

### 3.9 `scripts/factors_report.py` — 211 lines
`factors_report.py <dir-with-passN-factors.json>`; env `LITTLE_CPUS`. Five report sections; `cl0_share()` **remaps** the SQL's fixed partition against `LITTLE_CPUS`; 20-field per-iteration factor vector; 15 named correlation factors; hand-rolled `pearson`.

### 3.10 `scripts/cross_device_sections.py` — 108 lines
`cross_device_sections.py <label>=<dir> [...]`; reads `passN.json` (`continue` on missing); `SECTIONS` is a **16-entry** list (a *third* canonical set).

### 3.11 `scripts/verify_ab_arms.py` — 139 lines
`verify_ab_arms.py <a.apk> <b.apk> [<a-rebuilt.apk>]`; dex byte-position diff; exit 0 PASS/INCONCLUSIVE, 1 FAIL/WARNING, 2 usage.

### 3.12 References
`methodology.md` (201), `outlier-taxonomy.md` (72), `device-gotchas.md` (313 — worktree rule, config-flag A/B protocol, propagation gate, version-pin check).

---

## 4. `startup-longitudinal-tracking/`

**SKILL.md purpose (101 lines):** accumulate results over time into a persistent JSONL store anchored to a stable reference device set. Does **not** run benchmarks, does **not** average across device profiles.

**Workflow:** `reference_set.py --probe --out reference-set.json` → produce a run → `ingest_run.py <run-dir> --store <store.jsonl>` (**SKILL.md omits the required `--reference-set`**, see §7.3) → `trend_report.py --store <store.jsonl>`. Default shape **10×20**.

### 4.1 `scripts/reference_set.py` — 228 lines
- **CLI:** `reference_set.py [--probe] [--out PATH] [--check PATH] [--show PATH]`
- **Subprocess:** `adb devices`; `adb -s <serial> shell getprop`; `cat /proc/meminfo`; cpufreq maxima loop.
- **Notable:** `RECIPE_DEFAULT` with `instrument: None` **deliberately** so the first ingest fails loudly; `PROFILE_FIELDS` (8) drift set; `ram_class` buckets `<=2GB / 3-4GB / 6GB / >=8GB` (**incompatible with `device_probe.py`'s**); `coverage_warnings()`; `device_key` = `f"{tier}-{chr(ord('a')+i-1)}"`; `cool_gate_c` default 32.0.

### 4.2 `scripts/ingest_run.py` — 368 lines
- **CLI:** `ingest_run.py <run_dir> --reference-set PATH (req) --store PATH (req) [--device-key KEY] [--trace-processor PATH] [--lossy-tolerance FLOAT=2.0] [--dry-run] [--force] [--not-baseline]`
- **Subprocess:** `[tp, "-q", <tmp .sql>, <trace>]` (timeout 600), twice per trace (window; signals).
- **`_shared` imports:** `tooling.ensure_trace_processor`, `tooling.tool_provenance`; `trace_health.check_trace` (lazy).
- **Validation gates:** device identification via `--device-key` or serial→key; profile drift vs reference set; recipe `instrument` **must** be set; `build_type`/`compile_state` mismatches; three embedded SQL variants (`WINDOW_SQL`, `COMPOSED_WINDOW_SQL`, `SIGNALS_SQL`); trace health (drop `unusable`, count `lossy`, refuse above `--lossy-tolerance`); signal inventory only from a clean trace; **truncation guard** (`< 0.9 × expected`) and **over-long guard** (`> 1.1 × expected`); empty-run guard; `record_is_published()` excludes `snapshot`/`local`/`dirty`/`+`; `derive()` → `{n, median, p90, p95, max, iqr}` with index-based percentiles; `--force` stamps `notes`.
- **Hazard:** SQL temp files at fixed names in `tempfile.gettempdir()` (concurrency-unsafe).
- **Record schema:** `run_id, ingested_at, measured_at, device_key, device_profile, sdk_version, app_build_id, recipe{build_type, compile_state, instrument, run_shape, trace_processor_version, trace_processor_path}, conditions, baseline_eligible, signals_present, trace_health{…}, windows_ms[], derived{}, source_skill, notes`.

### 4.3 `scripts/trend_report.py` — 268 lines
- **CLI:** `trend_report.py --store PATH (required) [--baseline-runs INT=3] [--json PATH]`
- **`_shared` imports: none** (does not use `stats.py`).
- **Notable:** `group_key()` = `(device_key, sdk_version, build_type, compile_state, instrument, json(conditions))` — **sdk_version deliberately in the key**; baseline is **fixed** (first N eligible runs), never rolling; noise band = `max(4.0, spread of baseline medians %)`; `verdict()` → noise / candidate / REGRESSION / improvement, with `reproduced` requiring the previous delta to exceed the band with the same sign; tail-only detection; `signal_changes()`; p99 suppressed below n=500; separate `version_comparison()` never labelled regression.

### 4.4 References
`store.md` (155), `analysis.md` (95).

---

## 5. `startup-global-corpus/`

**SKILL.md purpose (105 lines):** pool results from many contributors/units keyed by device **MODEL + OS build**, and test reproducibility. Disagreement is the product.

### 5.1 `scripts/submit_run.py` — 201 lines
- **CLI:** `submit_run.py --store PATH --run-id ID --corpus PATH --contributor NAME [--serial SERIAL] [--lossy-tolerance FLOAT=0.0] [--dry-run]`
- **Subprocess:** `adb [-s serial] shell getprop` ×6, `pm list packages -3`, `df /data`, `dumpsys battery`, `uname -r`, `settings get global …` ×3.
- **Notable:** **allowlist, not denylist**; `unit_token = sha256(salt + serial)[:16]` with a local-only `.unit-salt`; coarse buckets; admissibility gates; `SCHEMA_VERSION = 1`.

### 5.2 `scripts/reproducibility_report.py` — 157 lines
- **CLI:** `reproducibility_report.py --corpus PATH [--json PATH]`
- **Notable:** `cell_key = (model, os_build, sdk_version, recipe-string, conditions)`; tolerance derived from the data's own within-run spread (`max(5.0, own_spread_pct)`); three independent verdicts (median spread, p90 spread, `shape_of()` two-state vs unimodal); requires ≥2 contributors or units; `HUNT_FIELDS` (12) — **two of which (`gate_temp_c`, `tool_versions`) are never written by `submit_run.py`**.

### 5.3 References
`contribution-schema.md` (106), `reproducibility.md` (84).

---

## 6. `startup-version-factor-matrix/`

**SKILL.md purpose (150 lines):** benchmark across SDK versions under one-factor-at-a-time cells of **10×20**, so version-to-version differences are attributable to the SDK.

### 6.1 `scripts/matrix_plan.py` — 177 lines
`matrix_plan.py <plan> [--emit cells.json]`. `cell_id = "<device>|<version>|k=v,…|reference"`; `build_cells()` (version sweep, one-factor-off, combos); `interleave()` (all version-sweep cells first); `estimate_seconds()` with `LAUNCH_SECONDS = {flagship:7, mid:9, entry:20}`, `PASS_OVERHEAD_S = 180`, `COOL_GATE_S = 300`; warns below 4 passes (cannot reach alpha) and below 10.

### 6.2 `scripts/cell_runner.py` — 346 lines
- **CLI:** `cell_runner.py --cells PATH --cell ID [--out DIR] [--check-only]`
- **Subprocess:** `adb devices`; many `adb shell` (thermalservice, `dumpsys package dexopt`, `pm list packages`, `settings get/put global stay_on_while_plugged_in`, airplane mode, `svc wifi`, `input keyevent 224`, `wm dismiss-keyguard`, `/sys/devices/system/cpu/present`, `pkill -9 dd`); `dd if=/dev/zero of=/dev/null` hogs; `gradlew :app:dependencies --configuration benchmarkRuntimeClasspath`; `pgrep -fl python3`; `git rev-parse HEAD`, `git status --short`; **`python3 fleet_campaign.py --serial … --out … --passes … --method … --iterations …` — does not match `fleet_campaign.py`'s CLI (§7.3)**.
- **Notable:** pidfile lock; invariants `check_host_quiet`, `check_sdk_matches` (resolved coordinate, never catalog text), `check_temperature`, `check_compile_state`; `apk_sha256`; contention dosing scaled to core count; `restore_state()` in `finally`; post-run `check_instrument()` samples first 5 + last 5 traces.
- **Provenance (`cell-state.json`):** `cell, plan_run_id, serial, device_profile, build_type, apk_sha256, repo_head, repo_dirty, catalog_pin, checks{}, started, instrument_check, finished`.

### 6.3 `scripts/compat_patch.py` — 175 lines
`compat_patch.py --version X --apply [--verify]` | `--revert-all`. `RECIPES` as data (`modern` ≥8.0; `7x`; `6x`); regex pin rewrite; journal-based snapshot/restore at `<EXAMPLE>/.vfm-compat-journal.json`. **Does not use `borrowed_state.py`** despite that module naming this pin as its motivating case.

### 6.4 `scripts/matrix_report.py` — 151 lines
`matrix_report.py <run_dir> [--slice NAME (default "app-embrace-start")] [--json PATH] [--trace-processor PATH]`. `summarize()` → `{n, median, p90, max, iqr, pass_medians}`; **pass-state flag** when `max(pass_medians) − min(pass_medians) > iqr`. SQL temp file at a fixed name (concurrency-unsafe).

### 6.5 References + plan
`design.md` (140), `factors.md` (151), `version-compat.md` (119), `plan-example.json` (73 — ships `passes:4, iterations:50` while SKILL.md mandates 10×20).

---

## 7. Duplication, inconsistencies, and porting risks

### 7.1 Logic reimplemented in multiple places

| Duplicated logic | Locations |
|---|---|
| **`pearson(xs, ys)`** — identical, character-for-character | `variance_analysis.py`, `hypothesis_tests.py`, `factors_report.py` (3 copies) |
| **trace_processor CSV extraction** (`[tp,"-q",sql,trace]`, `sys.executable` prefix, header sentinel, `[NULL]` skip) | `analyze_startup.py`, `variance_analysis.py`, `outlier_factors.py` (3 copies) |
| **"run a query, take the first float"** (temp .sql + subprocess + reversed-lines parse) | `ingest_run.py` ×2, `matrix_report.py`, `trace_health.py` (3–4 copies, different temp-file strategies) |
| **`repo_root()`** via `git rev-parse --show-toplevel` + walk-up fallback | `tooling.py`, `analyze_startup.py`, `fleet_campaign.py`, `cell_runner.py`, `compat_patch.py` (5 copies, 3 fallback strategies) |
| **Quantile** | index-based `values[min(len-1, int(p*len))]` in `ingest_run`, `trend_report`, `reproducibility_report`, `matrix_report`; a **different** convention in `hypothesis_tests.pctl`; a **third** (Type-7) in `stats.quantile`. **Three incompatible definitions.** |
| **`derive`/`summarize`** | `ingest_run.derive` (has `p95`, no `pass_medians`) vs `matrix_report.summarize` (has `pass_medians`, no `p95`) — the corpus reads `pass_medians`, which the documented pipeline never produces |
| **Published-version test** | `ingest_run.record_is_published`, `submit_run.published` |
| **Thermal parsing** | `device_probe.parse_thermal_sensors`, `fleet_campaign.parse_silicon_temps`, `cell_runner.check_temperature` (3 parsers, different regexes) |
| **adb wrapper** | 5 variants with timeouts 15 / 60 / 90 / 180 |
| **Canonical section list** | `analyze_startup` (13), `variance_analysis` (13+5), `cross_device_sections` (16), `hypothesis_tests` (subsets) — 4 divergent copies |
| **`ram_class`/`tier`** | `device_probe` (go/low/mid/high) vs `reference_set` (`<=2GB`…`>=8GB`) — incompatible vocabularies for the same field |
| **little-cluster remapping** | `--little-cpus` flag vs `LITTLE_CPUS` env var |
| **Statistics prose vs `stats.py`** | `matrix_plan.py`, `reference_set.py` restate the arguments inline instead of calling `stats.py` |

### 7.2 Dead / unwired code

- **`_shared/stats.py` (428 lines) is imported by nothing.** Every reporting script rolls its own comparison. Whether to wire it in is a decision for the port.
- **`_shared/borrowed_state.py` (90 lines) is imported by nothing**, though `compat_patch.py` mutates exactly the pin it was written for, with only a journal file.
- **`_shared/artifact_sync.py`** is a human/agent workflow tool, not called by any script.
- **`foreign_gc_overlap.sql`** and **`init_window_sched.sql`** have no driver.

### 7.3 CLI contract mismatches (each breaks a literal port)

1. **`cell_runner.py` → `fleet_campaign.py`**: invoked with `--serial/--out/--passes/--method/--iterations`; `fleet_campaign` accepts only positionals and has **no `--iterations`** (iteration count lives in `StartupBenchmarks.kt`). The delegation cannot work as written.
2. **version-factor-matrix SKILL.md step 3** says `--plan plan.json`; the script requires `--cells cells.json`.
3. **longitudinal SKILL.md step 2** omits the required `--reference-set`.
4. **Instrument name disagreement**: `cell_runner`/`matrix_report` default to `app-embrace-start`; `trace_health` defaults to `emb-sdk-start`; `reference_set.py` records that `app-embrace-start` was once "a span the harness never emits". Whether it exists in the current harness is ambiguous from the code alone.
5. **Run shape disagreement**: 4×50 in `startup-analysis` and `startup-multi-device-analysis`; 10×20 in `startup-longitudinal-tracking` and `startup-version-factor-matrix`; `plan-example.json` ships 4×50. Run shape is series-defining and `ingest_run.py` enforces it with ±10% guards.
6. **`HUNT_FIELDS`** includes `gate_temp_c` and `tool_versions`, which `submit_run.py` never writes.
7. **`reproducibility_report.py`** reads `derived.pass_medians`, which the documented upstream (`ingest_run.derive`) does not produce.

### 7.4 Concurrency / path hazards
- Fixed-name temp SQL files (`vfm_q.sql`, `longitudinal_window.sql`, `longitudinal_signals.sql`) are unsafe if two runs share a machine; only `trace_health.py` uses `mkstemp`.
- `artifact_sync.py`'s absolute `MANIFEST` path is the single blocker to running from another checkout.
- Non-recursive `os.listdir` (`analyze_startup`, `variance_analysis`, `outlier_factors`) vs recursive `rglob` (`ingest_run`, `matrix_report`, `cell_runner`, `trace_health`) — both load-bearing for their directory layouts.
