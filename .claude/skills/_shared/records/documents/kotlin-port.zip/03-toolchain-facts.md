# Toolchain facts the port design rests on

*Gathered 2026-08-26 directly from the repo and the installed tools. Each item is a fact, not a
recommendation; the recommendations are in `05-plan.md`.*

## The repo (branch `EMBR-13565/hho/multi-device-analysis`, HEAD `7b3c3cd8f`)

| fact | value | why it matters |
|---|---|---|
| Gradle wrapper | **9.7.1** | Any tools module gets Gradle for free; no install burden. |
| Kotlin Gradle plugin | **2.4.10** | Current Kotlin 2.x compiler; K2. |
| `kotlinCoreLibrariesVersion` | **2.0.21** | The stdlib API level the conventions pin to. |
| JVM target | **11** (`jvmTargetCompatibility = "11"`, `JvmTarget.JVM_11`) | Conventions pin `apiVersion`/`languageVersion` to `KOTLIN_2_0` and set `allWarningsAsErrors`. A tools module can use the convention as-is or a lighter one that targets 17/21. |
| JDK on this Mac | **OpenJDK 21.0.9 (JBR)** | Already present; Gradle 9 requires 17+. |
| JVM convention plugin | `embrace-jvm-conventions` (`kotlin("jvm")` + `embrace-common-conventions`) | **The precedent for a plain-JVM module**: `embrace-gradle-plugin` and `embrace-lint` use it. |
| detekt | **1.23.8**, applied by `embrace-common-conventions`, config `config/detekt/detekt.yml`, per-module `config/detekt/baseline.xml`, `detekt-formatting` (ktlint rules incl. trailing commas) | A tools module inherits detekt automatically via the convention. |
| Serialization | kotlinx-serialization **1.8.1** (core + json) in the catalog; plugin `kotlin-serialization` | JSON/JSONL without a new dependency. |
| Coroutines | kotlinx-coroutines **1.10.2** | Available if concurrency is wanted (parallel trace queries). |
| Also in catalog | moshi 1.15.2, okhttp (BOM), mockk, mockwebserver, junit **4.13.2** | JUnit 4 is the repo default; `embrace-gradle-plugin` tests use mockk + mockwebserver. |
| Gradle settings | `org.gradle.configuration-cache=true`, **`configuration-cache.problems=fail`**, `parallel=true`, `caching=true`, `-Xmx4096M` | Any custom task or `run` wiring must be configuration-cache compatible or the build fails. |
| Existing precedents | **No** Gradle `application` plugin anywhere (hits are `com.android.application`); **no** `.main.kts` scripts; `embrace-microbenchmark` is an Android library, not a JVM tool | The port introduces the first runnable JVM tool in the repo. |

## Perfetto `trace_processor` — what is actually pinned

The suite pins `TRACE_PROCESSOR_VERSION = "v46.0"` and downloads
`https://get.perfetto.dev/trace_processor` into `~/.cache/embrace-startup-tools/trace_processor/v46.0/`.

**That file is a Python launcher script** (`#!/usr/bin/env python3`), not a native binary. It carries a
manifest of platform prebuilts and downloads the matching `trace_processor_shell` into
`~/.local/share/perfetto/prebuilts/`, then executes it. Consequences:

1. **The current toolchain depends on python3 even for its "binary"** — the reason the Python
   scripts prefix `sys.executable` when the file is not executable.
2. **The pin does not pin the engine.** The launcher labelled v46.0 resolves to **Perfetto v57.2**
   prebuilts. The recipe's recorded `trace_processor_version: v46.0` therefore does not identify the
   analysis engine that produced the stored numbers. The native binary on this Mac is
   `trace_processor_shell-98a41b80e9f60da0` (v57.2, mac-arm64).

**Native prebuilt coordinates from the launcher manifest (v57.2):**

| platform | URL | sha256 | size |
|---|---|---|---|
| mac-arm64 | `https://commondatastorage.googleapis.com/perfetto-luci-artifacts/v57.2/mac-arm64/trace_processor_shell` | `98a41b80e9f60da0373d64aff6455681f8c26b7c391ae5736324a5b11e3dacc2` | 12,704,456 |
| mac-amd64 | `https://commondatastorage.googleapis.com/perfetto-luci-artifacts/v57.2/mac-amd64/trace_processor_shell` | `c0f61397901da47cbe1bb9a0843624f7c2038ac92176ce15e3736ce9aa0afef0` | — |

A port that fetches these directly, verifies the sha256, and records **v57.2** in the recipe removes
the Python dependency and fixes the provenance bug in one move. It is also a recipe change and must be
recorded as such (the store's `trace_processor_version` field changes meaning).

**Interfaces the native binary offers** (from `--help` on the installed prebuilt):

- Legacy flat flags — `trace_processor -q <file.sql> <trace>` — "fully supported and will remain so".
  This is what every Python script uses; output is CSV-like with a `"what","k","val"` header row and
  `[NULL]` for nulls.
- `query [FLAGS] <trace> [SQL]` — SQL positionally, via `-f file`, or stdin; **`--remote ADDR`** runs
  against a **warm session** instead of reloading the trace.
- `server <mode> [trace]` — `http` (default port **9001**, the same port `serve_trace.py` uses),
  `stdio` (length-prefixed RPC "used by tooling that embeds trace processor as a subprocess"),
  **`unix`** (AF_UNIX socket by `--name`/`--path`, "keeping the trace warm for repeated
  `query --remote` calls", `--idle-timeout`, `--daemonize`), `kill`.

**Why this matters for performance:** the Python parses every trace **once per query**. Ingest runs
the window query, the signals query and the health query as three separate processes per trace —
three full trace parses. A client that loads a trace into a warm session once and issues all queries
against it does the parse once. On a 200-trace leg that is the difference between ~600 and ~200
parses.

## Where the data is, and what did not survive

The session scratchpad under `/private/tmp` was **purged during this session** (for the second time
this week): every worktree, the branch-independent skills copy, the X35/X34 traces and all campaign
scratch are gone, freeing ~90 GB. `git worktree list` now shows `x34-worktree`, `x37-wt-compat` and
`x37-wt-kotlin` as **prunable** (`git worktree prune` clears them).

**Durable inputs available as parity fixtures**, all under `claude-output/` (19 MB total):

| fixture | shape | exercises |
|---|---|---|
| `longitudinal/store.jsonl` | 12 records, 200 windows each, 31.7 KB | ingest record schema, `derive()`, trend/verdict logic, version comparison, cluster stats at 10×20 |
| `longitudinal/sweep-store.jsonl` | 4 records (8.3.0 × 4 devices), 9.2 KB | same, on the non-baseline path |
| `longitudinal/reference-set.json` | 4 devices + recipe | device-key resolution, drift check, recipe validation |
| `2026-08-25-x35-attribution-10x20/*.json` | 6 files, per-section medians + `__window__` | attribution, proportional contrast, share-of-window |
| `2026-08-25-x34-attribution/*.json` | 8 files (adds flagship) | same, at the 4-pass shape |
| `2026-08-26-x37-engine-tail/*.json` | 22 per-leg `windows_ms[]` arrays | per-leg tail analysis, ABBA-arm bootstrap/permutation (data is VOID for conclusions; valid as a fixture) |
| `2026-08-26-x37-arm-reality-check/durations.json` | 2 × 20 tap durations | small paired-arm comparison |

**No raw `.perfetto-trace` file survives anywhere.** The trace-query layer (SQL + CSV parsing + trace
health) therefore has **no fixture** today; one must be captured deliberately (a handful of traces per
device, stored durably) before that layer can be tested for parity.
